// Customer Service Chatbot - AI Agent Starter Kit
// Built with LangChain + OpenAI
// Deploy in 1 hour, customize for any business

const { ChatOpenAI } = require("@langchain/openai");
const { ConversationChain } = require("langchain/chains");
const { BufferMemory } = require("langchain/memory");
const { PromptTemplate } = require("@langchain/core/prompts");
const { DynamicTool } = require("@langchain/core/tools");

class CustomerServiceBot {
    constructor(config = {}) {
        this.config = {
            modelName: config.modelName || "gpt-4",
            temperature: config.temperature || 0.7,
            maxTokens: config.maxTokens || 500,
            systemPrompt: config.systemPrompt || this.getDefaultSystemPrompt(),
            businessName: config.businessName || "Our Business",
            businessType: config.businessType || "general",
            knowledgeBase: config.knowledgeBase || [],
            tools: config.tools || [],
            ...config
        };

        this.llm = new ChatOpenAI({
            modelName: this.config.modelName,
            temperature: this.config.temperature,
            maxTokens: this.config.maxTokens,
            openAIApiKey: config.openAIApiKey || process.env.OPENAI_API_KEY
        });

        this.memory = new BufferMemory({
            returnMessages: true,
            memoryKey: "history"
        });

        this.conversationHistory = [];
        this.tools = this._initializeTools();
        this.chain = this._initializeChain();
    }

    getDefaultSystemPrompt() {
        return `You are a helpful customer service representative for {businessName}.

Your responsibilities:
1. Answer questions about our products/services
2. Help customers with common issues
3. Escalate complex problems to human agents
4. Collect customer information when needed
5. Provide a friendly, professional experience

Guidelines:
- Be concise but thorough
- Ask clarifying questions when needed
- Admit when you don't know something
- Offer to connect them with a human when appropriate
- Use the knowledge base to answer questions accurately

Knowledge Base:
{knowledgeBase}

Current conversation:
{history}
Customer: {input}
Assistant:`;
    }

    _initializeTools() {
        const defaultTools = [
            new DynamicTool({
                name: "lookup_order",
                description: "Look up order status by order ID",
                func: async (orderId) => {
                    // Replace with actual order lookup
                    return `Order ${orderId}: Processing - Expected delivery in 3-5 business days`;
                }
            }),
            new DynamicTool({
                name: "get_business_hours",
                description: "Get business hours",
                func: async () => {
                    return `${this.config.businessName} Hours:\nMonday-Friday: 9am - 6pm\nSaturday: 10am - 4pm\nSunday: Closed`;
                }
            }),
            new DynamicTool({
                name: "get_contact_info",
                description: "Get contact information",
                func: async () => {
                    return `Contact ${this.config.businessName}:\nEmail: support@${this.config.businessName.toLowerCase().replace(/\s+/g, '')}.com\nPhone: (555) 123-4567`;
                }
            }),
            new DynamicTool({
                name: "schedule_callback",
                description: "Schedule a callback with a human agent",
                func: async (details) => {
                    // Replace with actual scheduling logic
                    return `Callback scheduled! A human agent will contact you within 24 hours.`;
                }
            }),
            new DynamicTool({
                name: "submit_ticket",
                description: "Submit a support ticket",
                func: async (details) => {
                    const ticketId = `TKT-${Date.now().toString(36).toUpperCase()}`;
                    return `Support ticket created!\nTicket ID: ${ticketId}\nWe'll respond within 24 hours.`;
                }
            })
        ];

        return [...defaultTools, ...this.config.tools];
    }

    _initializeChain() {
        const prompt = new PromptTemplate({
            template: this.config.systemPrompt,
            inputVariables: ["businessName", "knowledgeBase", "history", "input"]
        });

        return new ConversationChain({
            llm: this.llm,
            memory: this.memory,
            prompt: prompt
        });
    }

    async chat(userInput, userId = null) {
        try {
            // Add to history
            this.conversationHistory.push({
                role: "user",
                content: userInput,
                timestamp: new Date().toISOString(),
                userId
            });

            // Check for tool usage
            const toolResponse = await this._checkForToolUse(userInput);
            if (toolResponse) {
                const response = {
                    message: toolResponse,
                    type: "tool_response",
                    timestamp: new Date().toISOString()
                };
                this.conversationHistory.push({
                    role: "assistant",
                    ...response
                });
                return response;
            }

            // Generate response
            const knowledgeBaseStr = this.config.knowledgeBase
                .map(kb => `- ${kb.question}: ${kb.answer}`)
                .join("\n");

            const response = await this.chain.call({
                input: userInput,
                businessName: this.config.businessName,
                knowledgeBase: knowledgeBaseStr || "No specific knowledge base loaded."
            });

            const assistantMessage = {
                message: response.response,
                type: "ai_response",
                timestamp: new Date().toISOString()
            };

            this.conversationHistory.push({
                role: "assistant",
                ...assistantMessage
            });

            return assistantMessage;

        } catch (error) {
            console.error("Chat error:", error);
            return {
                message: "I apologize, but I'm experiencing technical difficulties. Let me connect you with a human agent.",
                type: "error",
                timestamp: new Date().toISOString()
            };
        }
    }

    async _checkForToolUse(input) {
        const lowerInput = input.toLowerCase();

        // Simple keyword matching (replace with LLM tool calling for production)
        if (lowerInput.includes("order") && lowerInput.match(/\d+/)) {
            const orderId = lowerInput.match(/\d+/)[0];
            const tool = this.tools.find(t => t.name === "lookup_order");
            if (tool) return await tool.func(orderId);
        }

        if (lowerInput.includes("hours") || lowerInput.includes("open") || lowerInput.includes("close")) {
            const tool = this.tools.find(t => t.name === "get_business_hours");
            if (tool) return await tool.func();
        }

        if (lowerInput.includes("contact") || lowerInput.includes("phone") || lowerInput.includes("email")) {
            const tool = this.tools.find(t => t.name === "get_contact_info");
            if (tool) return await tool.func();
        }

        if (lowerInput.includes("call me") || lowerInput.includes("callback") || lowerInput.includes("speak to someone")) {
            const tool = this.tools.find(t => t.name === "schedule_callback");
            if (tool) return await tool.func(input);
        }

        if (lowerInput.includes("ticket") || lowerInput.includes("issue") || lowerInput.includes("problem")) {
            const tool = this.tools.find(t => t.name === "submit_ticket");
            if (tool) return await tool.func(input);
        }

        return null;
    }

    getHistory() {
        return this.conversationHistory;
    }

    clearHistory() {
        this.conversationHistory = [];
        this.memory.clear();
    }

    addKnowledge(question, answer) {
        this.config.knowledgeBase.push({ question, answer });
    }

    removeKnowledge(index) {
        if (index >= 0 && index < this.config.knowledgeBase.length) {
            this.config.knowledgeBase.splice(index, 1);
        }
    }

    getStats() {
        return {
            totalMessages: this.conversationHistory.length,
            userMessages: this.conversationHistory.filter(m => m.role === "user").length,
            assistantMessages: this.conversationHistory.filter(m => m.role === "assistant").length,
            toolResponses: this.conversationHistory.filter(m => m.type === "tool_response").length,
            averageResponseTime: this._calculateAverageResponseTime()
        };
    }

    _calculateAverageResponseTime() {
        // Implement response time tracking
        return 0;
    }
}

module.exports = CustomerServiceBot;