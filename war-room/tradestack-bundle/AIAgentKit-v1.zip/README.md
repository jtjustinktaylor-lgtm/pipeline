# AI Agent Starter Kits

> **Production-ready AI agents you can deploy in 1 hour.**
> Save 40+ hours of development time with pre-built, customizable chatbots.

---

## 🤖 Available Kits

### 1. Customer Service Bot
- Answer common questions
- Look up orders
- Schedule callbacks
- Submit support tickets
- Escalate to human agents

### 2. Sales Qualification Bot
- Qualify leads with BANT framework
- Score leads automatically
- Schedule demos
- Send proposals
- CRM integration

### 3. Content Generator
- Blog posts
- Social media content
- Email campaigns
- Product descriptions
- SEO optimization

---

## ⚡ Quick Start

### 1. Install Dependencies

```bash
npm install
```

### 2. Set Environment Variables

```bash
cp .env.example .env
# Add your OpenAI API key
```

### 3. Configure Your Agent

```javascript
const CustomerServiceBot = require('./src/chatbot');

const bot = new CustomerServiceBot({
    businessName: "Your Business",
    businessType: "ecommerce",
    knowledgeBase: [
        {
            question: "What is your return policy?",
            answer: "We accept returns within 30 days of purchase."
        },
        {
            question: "How long does shipping take?",
            answer: "Standard shipping takes 3-5 business days."
        }
    ]
});
```

### 4. Start Chatting

```javascript
const response = await bot.chat("What's your return policy?");
console.log(response.message);
```

---

## 🎯 Customization

### Add Knowledge Base

```javascript
bot.addKnowledge(
    "Do you offer discounts?",
    "Yes! We offer 10% off for first-time customers."
);
```

### Add Custom Tools

```javascript
const { DynamicTool } = require("@langchain/core/tools");

const customTool = new DynamicTool({
    name: "check_inventory",
    description: "Check product inventory",
    func: async (productId) => {
        // Your inventory logic here
        return `Product ${productId}: In stock (50 units)`;
    }
});

const bot = new CustomerServiceBot({
    tools: [customTool]
});
```

### Customize System Prompt

```javascript
const bot = new CustomerServiceBot({
    systemPrompt: `You are a friendly sales assistant for {businessName}.
    
Your goal is to help customers find the perfect product.

Guidelines:
- Ask about their needs and preferences
- Recommend products based on their answers
- Offer discounts when appropriate
- Collect contact information for follow-up

Knowledge Base:
{knowledgeBase}

Conversation History:
{history}

Customer: {input}
Assistant:`
});
```

---

## 🔌 Integration Examples

### Express.js API

```javascript
const express = require('express');
const CustomerServiceBot = require('./src/chatbot');

const app = express();
app.use(express.json());

const bot = new CustomerServiceBot({
    businessName: "Your Business"
});

app.post('/api/chat', async (req, res) => {
    const { message, userId } = req.body;
    const response = await bot.chat(message, userId);
    res.json(response);
});

app.listen(3000);
```

### React Component

```jsx
import { useState } from 'react';

function ChatWidget() {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');

    const sendMessage = async () => {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: input })
        });
        const data = await response.json();
        setMessages([...messages, 
            { role: 'user', content: input },
            { role: 'assistant', content: data.message }
        ]);
        setInput('');
    };

    return (
        <div className="chat-widget">
            <div className="messages">
                {messages.map((msg, i) => (
                    <div key={i} className={msg.role}>
                        {msg.content}
                    </div>
                ))}
            </div>
            <input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                placeholder="Type a message..."
            />
            <button onClick={sendMessage}>Send</button>
        </div>
    );
}
```

### Next.js API Route

```javascript
// pages/api/chat.js
import CustomerServiceBot from '../../src/chatbot';

const bot = new CustomerServiceBot({
    businessName: "Your Business"
});

export default async function handler(req, res) {
    if (req.method === 'POST') {
        const { message, userId } = req.body;
        const response = await bot.chat(message, userId);
        res.status(200).json(response);
    } else {
        res.status(405).json({ error: 'Method not allowed' });
    }
}
```

---

## 📊 Features Comparison

| Feature | Starter | Pro | Enterprise |
|---------|---------|-----|------------|
| **Knowledge Base** | 10 items | 100 items | Unlimited |
| **Custom Tools** | 3 | 10 | Unlimited |
| **Conversation Memory** | 10 messages | 50 messages | Unlimited |
| **Analytics** | Basic | Advanced | Custom |
| **Support** | Email | Priority | Dedicated |
| **Price** | $149 | $299 | $499 |

---

## 🧪 Testing

### Run Tests

```bash
npm test
```

### Test Coverage

```bash
npm run test:coverage
```

### Manual Testing

```javascript
const bot = new CustomerServiceBot({
    businessName: "Test Business"
});

// Test basic response
const response1 = await bot.chat("Hello");
console.log(response1);

// Test knowledge base
const response2 = await bot.chat("What are your hours?");
console.log(response2);

// Test tool usage
const response3 = await bot.chat("Check order #12345");
console.log(response3);
```

---

## 🚀 Deployment

### Vercel

```bash
vercel deploy
```

### Railway

```bash
railway up
```

### Docker

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3000
CMD ["node", "server.js"]
```

---

## 📈 Analytics

### Track Metrics

```javascript
const stats = bot.getStats();
console.log({
    totalMessages: stats.totalMessages,
    userMessages: stats.userMessages,
    assistantMessages: stats.assistantMessages,
    toolResponses: stats.toolResponses
});
```

### Export History

```javascript
const history = bot.getHistory();
// Save to database or file
```

---

## 🔒 Security

### Best Practices

1. **Never expose API keys** — Use environment variables
2. **Validate input** — Sanitize user messages
3. **Rate limiting** — Prevent abuse
4. **Logging** — Track all conversations
5. **Encryption** — Encrypt sensitive data

### Rate Limiting Example

```javascript
const rateLimit = require('express-rate-limit');

const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100 // limit each IP to 100 requests per windowMs
});

app.use('/api/chat', limiter);
```

---

## 💡 Use Cases

### E-commerce
- Product recommendations
- Order tracking
- Return processing
- FAQ answers

### SaaS
- Feature explanations
- Troubleshooting
- Account management
- Upgrade recommendations

### Real Estate
- Property inquiries
- Schedule viewings
- Mortgage questions
- Neighborhood info

### Healthcare
- Appointment scheduling
- Symptom triage
- Insurance questions
- Prescription refills

---

## 📚 Resources

- [LangChain Docs](https://docs.langchain.com/)
- [OpenAI API Docs](https://platform.openai.com/docs)
- [Express.js Docs](https://expressjs.com/)
- [Next.js Docs](https://nextjs.org/docs)

---

## 🆘 Support

- **Documentation:** [docs.nexgenai.dev](https://docs.nexgenai.dev)
- **Discord:** [discord.gg/nexgenai](https://discord.gg/nexgenai)
- **Email:** support@nexgenai.dev

---

## 📄 License

MIT License — See [LICENSE](LICENSE) for details.

---

**Built by NexGen AI — Deploy AI agents in 1 hour, not 2 weeks.**