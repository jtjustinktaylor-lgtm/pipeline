# 🎁 Web3 Starter Kit — FREE

Welcome! You just took your first step into Web3 development.

## What's Inside

### 1. Basic ERC-20 Token (`contracts/BasicToken.sol`)
A simple token you can deploy in minutes. Features:
- Standard transfer/approve/allowance
- Owner can mint new tokens
- Fixed max supply

### 2. Basic ERC-721 NFT (`contracts/BasicNFT.sol`)
Your first NFT contract. Features:
- Mint NFTs with metadata URIs
- Owner-only minting
- Works with OpenSea and other marketplaces

## Quick Start

### Prerequisites
- Node.js v18+
- npm or yarn

### Setup
```bash
# Initialize a Hardhat project
mkdir my-web3-project && cd my-web3-project
npx hardhat init

# Install OpenZeppelin
npm install @openzeppelin/contracts

# Copy the contracts from this kit into your contracts/ folder
cp contracts/BasicToken.sol ./contracts/
cp contracts/BasicNFT.sol ./contracts/
```

### Deploy
Create a deployment script:
```javascript
// scripts/deploy.js
const { ethers } = require("hardhat");

async function main() {
  // Deploy Token
  const Token = await ethers.getContractFactory("BasicToken");
  const token = await Token.deploy("My Token", "MTK", ethers.parseEther("100000"));
  await token.waitForDeployment();
  console.log("Token deployed to:", await token.getAddress());

  // Deploy NFT
  const NFT = await ethers.getContractFactory("BasicNFT");
  const nft = await NFT.deploy("My NFT", "MNFT", 10000);
  await nft.waitForDeployment();
  console.log("NFT deployed to:", await nft.getAddress());
}

main().catch(console.error);
```

```bash
npx hardhat run scripts/deploy.js --network localhost
```

## Next Steps

1. **Test locally** — Use `npx hardhat node` to spin up a local blockchain
2. **Get testnet ETH** — Use a faucet for Sepolia or Mumbai testnet
3. **Deploy to testnet** — Update `hardhat.config.js` with testnet RPC
4. **Verify on explorer** — Use `npx hardhat verify` on Etherscan

## Want More?

This is just the beginning. The **Smart Contract Pack** includes:
- Advanced ERC-20 with burn, pause, and role-based access
- Full NFT collection with royalties
- Staking platform with rewards
- Vesting contracts for teams
- MultiSig wallet for secure governance

**Get the full pack:** [gumroad.com/tradestack/smart-contract-pack]

---

Built by TradeStack — tools for builders. 🚀
