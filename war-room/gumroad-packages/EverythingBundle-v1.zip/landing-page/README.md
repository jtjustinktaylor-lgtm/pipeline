# NexGen AI — Landing Page

> **High-converting landing page for developer products.**
> Copy-paste ready. Deploy in minutes.

---

## 🚀 Quick Start

### Option 1: GitHub Pages (Free)

1. Create a new repository: `nexgenai-landing`
2. Copy `src/index.html`, `src/styles.css`, `src/script.js` to root
3. Go to Settings → Pages
4. Select "Deploy from branch" → `main` → `/ (root)`
5. Save and wait 2 minutes
6. Your site is live at `https://yourusername.github.io/nexgenai-landing`

### Option 2: Vercel (Recommended)

1. Install Vercel CLI: `npm i -g vercel`
2. Run `vercel` in the project directory
3. Follow the prompts
4. Done! Live at `https://nexgenai-landing.vercel.app`

### Option 3: Netlify

1. Drag and drop the `src` folder to [Netlify Drop](https://app.netlify.com/drop)
2. Done! Live at `https://random-name.netlify.app`

### Option 4: Custom Domain

1. Deploy to Vercel/Netlify
2. Add custom domain in settings
3. Update DNS records
4. SSL auto-configured

---

## 📁 File Structure

```
src/
├── index.html      # Main HTML (19KB)
├── styles.css      # All styles (11KB)
└── script.js       # Interactions (7KB)
```

---

## ✏️ Customization

### Change Colors

Edit `styles.css`:

```css
:root {
    --primary: #6366f1;        /* Main brand color */
    --primary-dark: #4f46e5;   /* Hover state */
    --secondary: #f59e0b;      /* Accent color */
    --success: #10b981;        /* Positive highlights */
    --danger: #ef4444;         /* Negative highlights */
}
```

### Change Prices

Edit `index.html`:

```html
<div class="price">
    <span class="currency">$</span>
    <span class="amount">299</span>  <!-- Change this -->
</div>
```

### Change Text

All text is in `index.html`. Search for the text you want to change and edit directly.

### Add Images

1. Create `public/images/` directory
2. Add your images
3. Reference in HTML: `<img src="images/your-image.png" alt="Description">`

---

## 🎨 Sections Included

| Section | Purpose |
|---------|---------|
| **Hero** | Main headline, CTA, social proof |
| **Problem** | Pain points your audience faces |
| **Solution** | Benefits of your product |
| **Products** | Feature grid with icons |
| **Time Saved** | Comparison table |
| **Testimonials** | Social proof |
| **Pricing** | 3-tier pricing cards |
| **FAQ** | Common questions |
| **Final CTA** | Last chance to convert |
| **Footer** | Links and info |

---

## 📱 Responsive Design

The landing page is fully responsive:

- **Desktop** (1024px+): Full layout
- **Tablet** (768px-1024px): 2-column grids
- **Mobile** (480px-768px): Single column
- **Small Mobile** (<480px): Compact layout

---

## 🚀 Performance

| Metric | Score |
|--------|-------|
| **Page Size** | ~38KB |
| **Load Time** | <1 second |
| **Lighthouse** | 95+ |
| **Mobile Friendly** | ✅ |

---

## 🔗 Integration

### Gumroad

Replace the button click handler in `script.js`:

```javascript
// In the pricing button click handler
window.location.href = 'https://gumroad.com/l/your-product-id';
```

### Stripe

Add Stripe Checkout:

```javascript
const stripe = Stripe('your-publishable-key');

async function checkout(priceId) {
    const { error } = await stripe.redirectToCheckout({
        lineItems: [{ price: priceId, quantity: 1 }],
        mode: 'payment',
        successUrl: window.location.href + '?success=true',
        cancelUrl: window.location.href + '?canceled=true',
    });
    
    if (error) {
        console.error(error);
    }
}
```

### Analytics

Add Google Analytics:

```html
<!-- In <head> -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXX"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-XXXXXXX');
</script>
```

### Email Signup

Add Mailchimp form:

```html
<form action="https://your-list.us1.list-manage.com/subscribe/post?u=xxx&id=xxx" method="post">
    <input type="email" name="EMAIL" placeholder="Enter your email" required>
    <button type="submit">Subscribe</button>
</form>
```

---

## 🧪 A/B Testing

### Test Different Headlines

```html
<!-- Version A -->
<h1>Save 40+ Hours.<br><span class="gradient">Deploy Today.</span></h1>

<!-- Version B -->
<h1>Stop Building From Scratch.<br><span class="gradient">Ship in 30 Minutes.</span></h1>
```

### Test Different CTAs

```html
<!-- Version A -->
<a href="#pricing" class="btn btn-primary btn-lg">
    Get the Template Pack — $299
</a>

<!-- Version B -->
<a href="#pricing" class="btn btn-primary btn-lg">
    Start Saving Time Now →
</a>
```

### Test Different Prices

```html
<!-- Version A -->
<span class="amount">299</span>

<!-- Version B -->
<span class="amount">249</span>
```

---

## 📊 Conversion Tips

1. **Above the fold** — Make sure headline and CTA are visible without scrolling
2. **Social proof** — Show testimonials and user count
3. **Urgency** — Add countdown timer or limited-time offer
4. **Risk reversal** — Money-back guarantee
5. **Clear CTA** — One primary action per section
6. **Mobile first** — Optimize for mobile users
7. **Fast loading** — Compress images, minimize code
8. **Trust signals** — Security badges, guarantees

---

## 🛠️ Troubleshooting

### Styles not loading

Check file paths in `index.html`:
```html
<link rel="stylesheet" href="styles.css">  <!-- Should match your file structure -->
```

### JavaScript not working

Check browser console for errors. Common issues:
- Missing closing tags
- Incorrect file paths
- Syntax errors

### Mobile layout broken

Make sure viewport meta tag is present:
```html
<meta name="viewport" content="width=device-width, initial-scale=1.0">
```

---

## 📚 Resources

- [CSS Variables](https://developer.mozilla.org/en-US/docs/Web/CSS/Using_CSS_custom_properties)
- [Flexbox Guide](https://css-tricks.com/snippets/css/a-guide-to-flexbox/)
- [Grid Guide](https://css-tricks.com/snippets/css/complete-guide-grid/)
- [Intersection Observer](https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API)

---

## 📄 License

MIT License — Use for personal and commercial projects.

---

**Built by NexGen AI — Convert visitors into customers.**