// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate');
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observe all sections
document.querySelectorAll('section').forEach(section => {
    observer.observe(section);
});

// Add animation classes
const style = document.createElement('style');
style.textContent = `
    section {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.6s ease, transform 0.6s ease;
    }
    
    section.animate {
        opacity: 1;
        transform: translateY(0);
    }
    
    .pain-point, .benefit, .product-card, .testimonial, .pricing-card, .faq-item {
        opacity: 0;
        transform: translateY(20px);
        transition: opacity 0.4s ease, transform 0.4s ease;
    }
    
    .animate .pain-point,
    .animate .benefit,
    .animate .product-card,
    .animate .testimonial,
    .animate .pricing-card,
    .animate .faq-item {
        opacity: 1;
        transform: translateY(0);
    }
    
    .animate .pain-point:nth-child(1),
    .animate .benefit:nth-child(1),
    .animate .product-card:nth-child(1),
    .animate .testimonial:nth-child(1),
    .animate .pricing-card:nth-child(1),
    .animate .faq-item:nth-child(1) {
        transition-delay: 0.1s;
    }
    
    .animate .pain-point:nth-child(2),
    .animate .benefit:nth-child(2),
    .animate .product-card:nth-child(2),
    .animate .testimonial:nth-child(2),
    .animate .pricing-card:nth-child(2),
    .animate .faq-item:nth-child(2) {
        transition-delay: 0.2s;
    }
    
    .animate .pain-point:nth-child(3),
    .animate .benefit:nth-child(3),
    .animate .product-card:nth-child(3),
    .animate .testimonial:nth-child(3),
    .animate .pricing-card:nth-child(3),
    .animate .faq-item:nth-child(3) {
        transition-delay: 0.3s;
    }
    
    .animate .pain-point:nth-child(4),
    .animate .benefit:nth-child(4),
    .animate .product-card:nth-child(4),
    .animate .pricing-card:nth-child(4),
    .animate .faq-item:nth-child(4) {
        transition-delay: 0.4s;
    }
    
    .animate .product-card:nth-child(5),
    .animate .faq-item:nth-child(5) {
        transition-delay: 0.5s;
    }
    
    .animate .faq-item:nth-child(6) {
        transition-delay: 0.6s;
    }
`;
document.head.appendChild(style);

// Navbar scroll effect
let lastScroll = 0;
const navbar = document.querySelector('nav');

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 100) {
        document.body.classList.add('scrolled');
    } else {
        document.body.classList.remove('scrolled');
    }
    
    lastScroll = currentScroll;
});

// Add scrolled styles
const navStyle = document.createElement('style');
navStyle.textContent = `
    body.scrolled nav {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        box-shadow: var(--shadow);
    }
`;
document.head.appendChild(navStyle);

// Counter animation (for stats if added)
function animateCounter(element, target, duration = 2000) {
    let start = 0;
    const increment = target / (duration / 16);
    
    const timer = setInterval(() => {
        start += increment;
        if (start >= target) {
            element.textContent = target;
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(start);
        }
    }, 16);
}

// Pricing button click handlers
document.querySelectorAll('.pricing-card .btn').forEach(button => {
    button.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Get product name
        const card = this.closest('.pricing-card');
        const productName = card.querySelector('h3').textContent;
        const price = card.querySelector('.amount').textContent;
        
        // Track event (replace with your analytics)
        console.log('Purchase clicked:', productName, price);
        
        // Show modal or redirect to checkout
        alert(`Redirecting to checkout for ${productName} ($${price})...`);
        
        // In production, redirect to Gumroad/Lemon Squeezy
        // window.location.href = 'https://gumroad.com/l/your-product';
    });
});

// Add hover effect to product cards
document.querySelectorAll('.product-card').forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-8px)';
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
    });
});

// Add ripple effect to buttons
document.querySelectorAll('.btn').forEach(button => {
    button.addEventListener('click', function(e) {
        const ripple = document.createElement('span');
        const rect = this.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = e.clientX - rect.left - size / 2;
        const y = e.clientY - rect.top - size / 2;
        
        ripple.style.cssText = `
            position: absolute;
            width: ${size}px;
            height: ${size}px;
            left: ${x}px;
            top: ${y}px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            transform: scale(0);
            animation: ripple 0.6s linear;
            pointer-events: none;
        `;
        
        this.style.position = 'relative';
        this.style.overflow = 'hidden';
        this.appendChild(ripple);
        
        setTimeout(() => ripple.remove(), 600);
    });
});

// Add ripple animation
const rippleStyle = document.createElement('style');
rippleStyle.textContent = `
    @keyframes ripple {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
`;
document.head.appendChild(rippleStyle);

// Lazy load images (if any)
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.add('loaded');
                imageObserver.unobserve(img);
            }
        });
    });
    
    document.querySelectorAll('img[data-src]').forEach(img => {
        imageObserver.observe(img);
    });
}

// Add loading state
window.addEventListener('load', () => {
    document.body.classList.add('loaded');
});

// Console greeting
console.log(`
%c🚀 NexGen AI Developer Products
%cBuilt with ❤️ for developers

Questions? Email us at support@nexgenai.dev
`,
    'font-size: 20px; font-weight: bold;',
    'font-size: 14px; color: #6b7280;'
);