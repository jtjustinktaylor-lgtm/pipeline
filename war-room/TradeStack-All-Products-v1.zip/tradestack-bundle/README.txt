# TradeStack — All Products

## Upload Order

1. **EverythingBundle-v1.zip** → $499 (flagship product)
2. **SmartContractPack-v1.zip** → $299
3. **AIAgentKit-v1.zip** → $149
4. **SaaSBoilerplate-v1.zip** → $149
5. **Web3StarterKit-FREE.zip** → $0 (free lead magnet)

## Quick Setup

1. Go to payhip.com → Create account
2. Connect Stripe or PayPal
3. Add Product → Digital Download
4. Copy title/price/description from quick-start.md
5. Upload the matching ZIP
6. Repeat for all 5 products
7. Create discount code: LAUNCH50 (50% off, 48 hours)

## Discount Codes to Create

| Code | Discount | Purpose |
|------|----------|---------|
| LAUNCH50 | 50% off | First 48 hours |
| FRIEND20 | 20% off | Referrals |
| BUNDLE200 | $200 off | Push bundle sales |
| TRADESTACK | 10% off | General promo |

## Your Store

URL: payhip.com/tradestack

Built by Justin @ TradeStack — A plumber who codes 🔧
