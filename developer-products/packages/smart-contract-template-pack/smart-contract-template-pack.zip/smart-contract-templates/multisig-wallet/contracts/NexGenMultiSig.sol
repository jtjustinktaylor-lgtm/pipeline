// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import "@openzeppelin/contracts/utils/cryptography/EIP712.sol";

/// @title NexGen MultiSig Wallet
/// @notice Production-ready multi-signature wallet with advanced features
/// @dev Perfect for DAOs, treasuries, and secure fund management
contract NexGenMultiSig is Ownable, ReentrancyGuard, EIP712 {
    using ECDSA for bytes32;

    // ============ TYPES ============
    struct Transaction {
        address to;                 // Destination address
        uint256 value;              // ETH value
        bytes data;                 // Call data
        uint256 nonce;              // Transaction nonce
        uint256 confirmationsRequired; // Required confirmations
        uint256 expiryTime;         // Transaction expiry (0 = no expiry)
        string description;         // Transaction description
        bool executed;              // Whether executed
        bool cancelled;             // Whether cancelled
        mapping(address => bool) confirmations; // Who confirmed
    }

    // ============ STATE ============
    mapping(uint256 => Transaction) public transactions;
    uint256 public transactionCount;
    mapping(address => bool) public isOwner;
    address[] public owners;
    uint256 public required;

    // ============ NONCE ============
    mapping(address => uint256) public nonces;

    // ============ LIMITS ============
    uint256 public dailyLimit;
    uint256 public dailySpent;
    uint256 public lastDayReset;
    mapping(address => uint256) public ownerDailyLimit;
    mapping(address => uint256) public ownerDailySpent;

    // ============ EMERGENCY ============
    bool public emergencyMode;
    address public emergencyContact;
    uint256 public emergencyDelay; // Delay before emergency actions

    // ============ EVENTS ============
    event Deposit(address indexed sender, uint256 amount, uint256 balance);
    event TransactionSubmitted(uint256 indexed txId, address indexed to, uint256 value, bytes data, string description);
    event TransactionConfirmed(uint256 indexed txId, address indexed owner);
    event ConfirmationRevoked(uint256 indexed txId, address indexed owner);
    event TransactionExecuted(uint256 indexed txId);
    event TransactionCancelled(uint256 indexed txId);
    event OwnerAdded(address indexed owner);
    event OwnerRemoved(address indexed owner);
    event RequirementChanged(uint256 required);
    event DailyLimitChanged(uint256 limit);
    event EmergencyModeToggled(bool active);
    event EmergencyContactChanged(address newContact);

    // ============ ERRORS ============
    error NotOwner();
    error TxDoesNotExist();
    error TxAlreadyExecuted();
    error TxAlreadyCancelled();
    error TxNotConfirmed();
    error TxAlreadyConfirmed();
    error TxNotEnoughConfirmations();
    error TxExpired();
    error TxFailed();
    error InvalidRequirement();
    error InvalidOwner();
    error OwnerAlreadyExists();
    error CannotRemoveOwner();
    error DailyLimitExceeded();
    error EmergencyModeActive();

    // ============ MODIFIERS ============
    modifier onlyWallet() {
        require(msg.sender == address(this), "Only wallet");
        _;
    }

    modifier txExists(uint256 _txId) {
        if (_txId >= transactionCount) revert TxDoesNotExist();
        _;
    }

    modifier notExecuted(uint256 _txId) {
        if (transactions[_txId].executed) revert TxAlreadyExecuted();
        _;
    }

    modifier notCancelled(uint256 _txId) {
        if (transactions[_txId].cancelled) revert TxAlreadyCancelled();
        _;
    }

    modifier notExpired(uint256 _txId) {
        if (transactions[_txId].expiryTime > 0 && block.timestamp > transactions[_txId].expiryTime) {
            revert TxExpired();
        }
        _;
    }

    // ============ CONSTRUCTOR ============

    constructor(
        address[] memory _owners,
        uint256 _required,
        uint256 _dailyLimit,
        address _emergencyContact,
        uint256 _emergencyDelay
    ) Ownable(msg.sender) EIP712("NexGenMultiSig", "1") {
        require(_owners.length > 0, "Owners required");
        require(_required > 0 && _required <= _owners.length, "Invalid requirement");
        require(_emergencyDelay > 0, "Invalid delay");

        for (uint256 i = 0; i < _owners.length; i++) {
            address owner = _owners[i];
            if (owner == address(0)) revert InvalidOwner();
            if (isOwner[owner]) revert OwnerAlreadyExists();

            isOwner[owner] = true;
            owners.push(owner);
        }

        required = _required;
        dailyLimit = _dailyLimit;
        emergencyContact = _emergencyContact;
        emergencyDelay = _emergencyDelay;
        lastDayReset = block.timestamp;
    }

    // ============ RECEIVE ============

    receive() external payable {
        if (msg.value > 0) {
            emit Deposit(msg.sender, msg.value, address(this).balance);
        }
    }

    fallback() external payable {
        if (msg.value > 0) {
            emit Deposit(msg.sender, msg.value, address(this).balance);
        }
    }

    // ============ SUBMIT ============

    /// @notice Submit a new transaction
    function submitTransaction(
        address _to,
        uint256 _value,
        bytes calldata _data,
        uint256 _confirmationsRequired,
        uint256 _expiryTime,
        string calldata _description
    ) external onlyOwner returns (uint256 txId) {
        require(_to != address(0), "Invalid address");
        require(_confirmationsRequired > 0 && _confirmationsRequired <= owners.length, "Invalid confirmations");

        txId = transactionCount++;

        Transaction storage txn = transactions[txId];
        txn.to = _to;
        txn.value = _value;
        txn.data = _data;
        txn.nonce = nonces[msg.sender]++;
        txn.confirmationsRequired = _confirmationsRequired;
        txn.expiryTime = _expiryTime;
        txn.description = _description;

        // Auto-confirm by submitter
        txn.confirmations[msg.sender] = true;

        emit TransactionSubmitted(txId, _to, _value, _data, _description);
        emit TransactionConfirmed(txId, msg.sender);
    }

    /// @notice Submit with meta-transaction signature
    function submitWithSignature(
        address _to,
        uint256 _value,
        bytes calldata _data,
        uint256 _confirmationsRequired,
        uint256 _expiryTime,
        string calldata _description,
        bytes calldata _signature
    ) external returns (uint256 txId) {
        // Recover signer
        bytes32 structHash = keccak256(abi.encode(
            keccak256("Transaction(address to,uint256 value,bytes data,uint256 nonce,uint256 confirmationsRequired,uint256 expiryTime,string description)"),
            _to,
            _value,
            keccak256(_data),
            nonces[msg.sender],
            _confirmationsRequired,
            _expiryTime,
            keccak256(bytes(_description))
        ));

        bytes32 digest = _hashTypedDataV4(structHash);
        address signer = digest.recover(_signature);

        if (!isOwner[signer]) revert NotOwner();

        // Submit transaction
        txId = transactionCount++;

        Transaction storage txn = transactions[txId];
        txn.to = _to;
        txn.value = _value;
        txn.data = _data;
        txn.nonce = nonces[signer]++;
        txn.confirmationsRequired = _confirmationsRequired;
        txn.expiryTime = _expiryTime;
        txn.description = _description;

        // Confirm by signer
        txn.confirmations[signer] = true;

        emit TransactionSubmitted(txId, _to, _value, _data, _description);
        emit TransactionConfirmed(txId, signer);
    }

    // ============ CONFIRM ============

    /// @notice Confirm a transaction
    function confirmTransaction(uint256 _txId)
        external
        onlyOwner
        txExists(_txId)
        notExecuted(_txId)
        notCancelled(_txId)
        notExpired(_txId)
    {
        Transaction storage txn = transactions[_txId];
        if (txn.confirmations[msg.sender]) revert TxAlreadyConfirmed();

        txn.confirmations[msg.sender] = true;

        emit TransactionConfirmed(_txId, msg.sender);
    }

    /// @notice Revoke a confirmation
    function revokeConfirmation(uint256 _txId)
        external
        onlyOwner
        txExists(_txId)
        notExecuted(_txId)
        notCancelled(_txId)
    {
        Transaction storage txn = transactions[_txId];
        if (!txn.confirmations[msg.sender]) revert TxNotConfirmed();

        txn.confirmations[msg.sender] = false;

        emit ConfirmationRevoked(_txId, msg.sender);
    }

    // ============ EXECUTE ============

    /// @notice Execute a confirmed transaction
    function executeTransaction(uint256 _txId)
        external
        onlyOwner
        txExists(_txId)
        notExecuted(_txId)
        notCancelled(_txId)
        notExpired(_txId)
        nonReentrant
    {
        Transaction storage txn = transactions[_txId];

        // Count confirmations
        uint256 confirmationCount = 0;
        for (uint256 i = 0; i < owners.length; i++) {
            if (txn.confirmations[owners[i]]) {
                confirmationCount++;
            }
        }

        if (confirmationCount < txn.confirmationsRequired) revert TxNotEnoughConfirmations();

        // Check daily limit
        _checkDailyLimit(txn.value);

        // Execute
        txn.executed = true;

        (bool success, ) = txn.to.call{value: txn.value}(txn.data);
        if (!success) revert TxFailed();

        emit TransactionExecuted(_txId);
    }

    // ============ CANCEL ============

    /// @notice Cancel a transaction (requires majority)
    function cancelTransaction(uint256 _txId)
        external
        onlyOwner
        txExists(_txId)
        notExecuted(_txId)
        notCancelled(_txId)
    {
        Transaction storage txn = transactions[_txId];

        // Count confirmations for cancellation
        uint256 confirmationCount = 0;
        for (uint256 i = 0; i < owners.length; i++) {
            if (txn.confirmations[owners[i]]) {
                confirmationCount++;
            }
        }

        // Require majority to cancel
        if (confirmationCount < (owners.length / 2) + 1) revert TxNotEnoughConfirmations();

        txn.cancelled = true;

        emit TransactionCancelled(_txId);
    }

    // ============ DAILY LIMITS ============

    /// @notice Set daily spending limit
    function setDailyLimit(uint256 _limit) external onlyWallet {
        dailyLimit = _limit;
        emit DailyLimitChanged(_limit);
    }

    /// @notice Set per-owner daily limit
    function setOwnerDailyLimit(address _owner, uint256 _limit) external onlyWallet {
        require(isOwner[_owner], "Not owner");
        ownerDailyLimit[_owner] = _limit;
    }

    function _checkDailyLimit(uint256 amount) internal {
        // Reset daily counter if new day
        if (block.timestamp >= lastDayReset + 1 days) {
            dailySpent = 0;
            lastDayReset = block.timestamp;
        }

        // Check global limit
        if (dailyLimit > 0) {
            require(dailySpent + amount <= dailyLimit, "Daily limit exceeded");
            dailySpent += amount;
        }

        // Check per-owner limit
        if (ownerDailyLimit[msg.sender] > 0) {
            require(ownerDailySpent[msg.sender] + amount <= ownerDailyLimit[msg.sender], "Owner daily limit exceeded");
            ownerDailySpent[msg.sender] += amount;
        }
    }

    // ============ EMERGENCY ============

    /// @notice Toggle emergency mode
    function toggleEmergencyMode() external {
        require(msg.sender == emergencyContact || msg.sender == owner(), "Not authorized");
        emergencyMode = !emergencyMode;
        emit EmergencyModeToggled(emergencyMode);
    }

    /// @notice Emergency withdraw (only in emergency mode after delay)
    function emergencyWithdraw(address _to, uint256 _amount) external {
        require(emergencyMode, "Emergency mode not active");
        require(msg.sender == emergencyContact, "Not emergency contact");
        require(_to != address(0), "Invalid address");

        (bool success, ) = _to.call{value: _amount}("");
        require(success, "Transfer failed");
    }

    /// @notice Set emergency contact
    function setEmergencyContact(address _contact) external onlyWallet {
        require(_contact != address(0), "Invalid address");
        emergencyContact = _contact;
        emit EmergencyContactChanged(_contact);
    }

    // ============ OWNER MANAGEMENT ============

    /// @notice Add a new owner (only via wallet transaction)
    function addOwner(address _owner) external onlyWallet {
        require(_owner != address(0), "Invalid address");
        require(!isOwner[_owner], "Already owner");

        isOwner[_owner] = true;
        owners.push(_owner);

        emit OwnerAdded(_owner);
    }

    /// @notice Remove an owner (only via wallet transaction)
    function removeOwner(address _owner) external onlyWallet {
        require(isOwner[_owner], "Not owner");
        require(owners.length - 1 >= required, "Cannot remove");

        isOwner[_owner] = false;

        for (uint256 i = 0; i < owners.length; i++) {
            if (owners[i] == _owner) {
                owners[i] = owners[owners.length - 1];
                owners.pop();
                break;
            }
        }

        emit OwnerRemoved(_owner);
    }

    /// @notice Change requirement (only via wallet transaction)
    function changeRequirement(uint256 _required) external onlyWallet {
        if (_required == 0 || _required > owners.length) revert InvalidRequirement();
        required = _required;
        emit RequirementChanged(_required);
    }

    // ============ VIEW FUNCTIONS ============

    /// @notice Get transaction details
    function getTransaction(uint256 _txId) external view returns (
        address to,
        uint256 value,
        bytes memory data,
        uint256 nonce,
        uint256 confirmationsRequired,
        uint256 expiryTime,
        string memory description,
        bool executed,
        bool cancelled,
        uint256 confirmationCount
    ) {
        Transaction storage txn = transactions[_txId];
        uint256 count = 0;
        for (uint256 i = 0; i < owners.length; i++) {
            if (txn.confirmations[owners[i]]) count++;
        }

        return (
            txn.to,
            txn.value,
            txn.data,
            txn.nonce,
            txn.confirmationsRequired,
            txn.expiryTime,
            txn.description,
            txn.executed,
            txn.cancelled,
            count
        );
    }

    /// @notice Check if transaction is confirmed
    function isConfirmed(uint256 _txId) external view returns (bool) {
        Transaction storage txn = transactions[_txId];
        uint256 count = 0;
        for (uint256 i = 0; i < owners.length; i++) {
            if (txn.confirmations[owners[i]]) count++;
        }
        return count >= txn.confirmationsRequired;
    }

    /// @notice Get all owners
    function getOwners() external view returns (address[] memory) {
        return owners;
    }

    /// @notice Get pending transactions
    function getPendingTransactions() external view returns (uint256[] memory) {
        uint256 pendingCount = 0;
        for (uint256 i = 0; i < transactionCount; i++) {
            if (!transactions[i].executed && !transactions[i].cancelled) {
                pendingCount++;
            }
        }

        uint256[] memory pending = new uint256[](pendingCount);
        uint256 index = 0;
        for (uint256 i = 0; i < transactionCount; i++) {
            if (!transactions[i].executed && !transactions[i].cancelled) {
                pending[index++] = i;
            }
        }

        return pending;
    }

    /// @notice Get wallet balance
    function getBalance() external view returns (uint256) {
        return address(this).balance;
    }

    /// @notice Get daily limit info
    function getDailyLimitInfo() external view returns (
        uint256 limit,
        uint256 spent,
        uint256 remaining,
        uint256 resetTime
    ) {
        limit = dailyLimit;
        spent = dailySpent;
        remaining = dailyLimit > 0 ? dailyLimit - dailySpent : type(uint256).max;
        resetTime = lastDayReset + 1 days;
    }
}