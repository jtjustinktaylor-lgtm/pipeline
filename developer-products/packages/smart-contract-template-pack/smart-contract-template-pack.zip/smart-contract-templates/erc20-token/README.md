# NexGen ERC-20 Token Template

> **Production-ready ERC-20 token with tax, anti-bot, and advanced features.**
> Perfect for DeFi projects, DAOs, and token launches.

---

## 🚀 Features

- ✅ **ERC-20 Standard** — Full compliance with OpenZeppelin
- ✅ **Buy/Sell Tax** — Configurable up to 10%
- ✅ **Anti-Bot Protection** — Max tx/wallet, bot blacklisting
- ✅ **Trading Control** — Enable trading when ready
- ✅ **Tax Exemptions** — Exclude addresses from tax/limits
- ✅ **Burnable** — Token burning capability
- ✅ **Permit** — Gasless approvals (EIP-2612)
- ✅ **Ownable** — Admin functions with ownership transfer
- ✅ **Events** — Full event logging for transparency

---

## 📦 What's Included

```
erc20-token/
├── contracts/
│   └── NexGenToken.sol          # Main contract (8.5KB)
├── scripts/
│   └── deploy.js                # Deployment script
├── test/
│   └── NexGenToken.test.js      # 100% test coverage
├── hardhat.config.js            # Hardhat configuration
├── package.json                 # Dependencies
├── .env.example                 # Environment variables template
└── README.md                    # This file
```

---

## ⚡ Quick Start

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your keys
```

### 3. Compile Contracts

```bash
npx hardhat compile
```

### 4. Run Tests

```bash
npx hardhat test
```

### 5. Deploy

```bash
# Local
npx hardhat run scripts/deploy.js

# Testnet (Goerli)
npx hardhat run scripts/deploy.js --network goerli

# Mainnet
npx hardhat run scripts/deploy.js --network mainnet
```

---

## 🔧 Configuration

### Constructor Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | string | Token name (e.g., "My Token") |
| `symbol` | string | Token symbol (e.g., "MTK") |
| `initialSupply` | uint256 | Total supply (with decimals) |
| `taxWallet` | address | Wallet to receive tax fees |
| `initialOwner` | address | Contract owner address |

### Example Deployment

```javascript
const token = await NexGenToken.deploy(
    "My Token",           // name
    "MTK",                // symbol
    ethers.parseEther("1000000000"), // 1 billion tokens
    "0xTaxWallet...",     // tax wallet
    "0xOwner..."          // owner
);
```

---

## 📊 Tax Configuration

### Default Tax Rates

| Type | Rate | Basis Points |
|------|------|--------------|
| Buy Tax | 2% | 200 |
| Sell Tax | 3% | 300 |

### Update Tax

```javascript
// Set buy tax to 1%, sell tax to 2%
await token.setTaxes(100, 200);
```

### Tax Exemptions

```javascript
// Exclude address from tax
await token.excludeFromTax("0xAddress...", true);

// Exclude address from limits
await token.excludeFromLimits("0xAddress...", true);
```

---

## 🛡️ Anti-Bot Protection

### Features

- **Max Transaction Amount** — Limits per-transaction size
- **Max Wallet Amount** — Limits per-wallet holdings
- **Bot Blacklist** — Block known bot addresses
- **Trading Delay** — Enable trading when ready

### Configuration

```javascript
// Set max transaction to 1% of supply
await token.setMaxTxAmount(ethers.parseEther("10000000"));

// Set max wallet to 2% of supply
await token.setMaxWalletAmount(ethers.parseEther("20000000"));

// Mark bot addresses
await token.markBot("0xBotAddress...");

// Enable trading (after launch setup)
await token.enableTrading();
```

---

## 🔐 Security Features

### Access Control

- **Owner-only functions** — Admin operations protected
- **Ownership transfer** — Secure ownership handoff
- **Renounce ownership** — Make fully decentralized

### Transfer Validation

- **Anti-bot checks** — Block blacklisted addresses
- **Trading delay** — Prevent pre-launch dumps
- **Amount limits** — Prevent whale manipulation
- **Wallet limits** — Distribute token ownership

### Tax Security

- **Max tax cap** — 10% maximum enforced
- **Tax wallet validation** — Cannot be zero address
- **Fee collection** — Transparent fee tracking

---

## 📈 Launch Checklist

### Pre-Launch

- [ ] Deploy contract
- [ ] Set tax wallet
- [ ] Configure tax rates
- [ ] Set max tx/wallet amounts
- [ ] Add initial liquidity (if DEX)
- [ ] Exclude LP from tax/limits

### Launch

- [ ] Enable trading
- [ ] Monitor for bots
- [ ] Mark any bot addresses
- [ ] Adjust limits if needed

### Post-Launch

- [ ] Monitor tax collection
- [ ] Adjust tax rates if needed
- [ ] Collect accumulated fees
- [ ] Consider renouncing ownership

---

## 🧪 Testing

### Run All Tests

```bash
npx hardhat test
```

### Test Coverage

```bash
npx hardhat coverage
```

### Test Scenarios

- ✅ Token deployment
- ✅ Tax collection on buy/sell
- ✅ Anti-bot protection
- ✅ Trading enable/disable
- ✅ Max tx/wallet enforcement
- ✅ Tax exemptions
- ✅ Bot marking/unmarking
- ✅ Fee withdrawal
- ✅ Ownership transfer

---

## 🔗 Deployment Networks

### Supported Networks

| Network | Chain ID | RPC |
|---------|----------|-----|
| Ethereum Mainnet | 1 | https://mainnet.infura.io/v3/... |
| Goerli Testnet | 5 | https://goerli.infura.io/v3/... |
| Paxeer Network | 125 | https://public-rpc.paxeer.app/evm/reference |
| BSC Mainnet | 56 | https://bsc-dataseed.binance.org/ |
| Polygon | 137 | https://polygon-rpc.com/ |

### Network Configuration

```javascript
// hardhat.config.js
networks: {
    paxeer: {
        url: "https://public-rpc.paxeer.app/evm/reference",
        chainId: 125,
        accounts: [process.env.PRIVATE_KEY]
    }
}
```

---

## 💡 Customization Guide

### Add Reflections (Reward Holders)

```solidity
// Add to _update function
function _distributeReflection(uint256 amount) private {
    // Distribute to holders based on balance
}
```

### Add Auto-Liquidity

```solidity
// Add to _update function
function _addLiquidity(uint256 amount) private {
    // Auto-add to LP
}
```

### Add Burn Mechanism

```solidity
// Already included via ERC20Burnable
function burn(uint256 amount) public {
    _burn(msg.sender, amount);
}
```

---

## 📚 Resources

- [OpenZeppelin Docs](https://docs.openzeppelin.com/)
- [Hardhat Docs](https://hardhat.org/docs)
- [Solidity Docs](https://docs.soliditylang.org/)
- [ERC-20 Standard](https://eips.ethereum.org/EIPS/eip-20)

---

## 🆘 Support

- **Documentation:** [docs.nexgenai.dev](https://docs.nexgenai.dev)
- **Discord:** [discord.gg/nexgenai](https://discord.gg/nexgenai)
- **Email:** support@nexgenai.dev

---

## 📄 License

MIT License — See [LICENSE](LICENSE) for details.

---

## ⚠️ Disclaimer

This template is provided as-is for educational purposes. Always:
- Get a professional audit before mainnet deployment
- Test thoroughly on testnets first
- Understand the risks of smart contract deployment
- Comply with local regulations

---

**Built by NexGen AI — Save 40+ hours of development time.**