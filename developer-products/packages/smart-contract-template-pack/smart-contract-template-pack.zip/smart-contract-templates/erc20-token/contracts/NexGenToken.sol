// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

/// @title NexGen ERC-20 Token
/// @notice Production-ready ERC-20 with tax, anti-bot, and advanced features
/// @dev Perfect for DeFi projects, DAOs, and token launches
contract NexGenToken is ERC20, ERC20Burnable, ERC20Permit, Ownable {
    // ============ TAX CONFIGURATION ============
    uint256 public buyTax = 200; // 2% (in basis points, 10000 = 100%)
    uint256 public sellTax = 300; // 3%
    uint256 public constant MAX_TAX = 1000; // 10% max
    address public taxWallet;

    // ============ ANTI-BOT PROTECTION ============
    bool public antiBotEnabled = true;
    uint256 public maxTxAmount;
    uint256 public maxWalletAmount;
    mapping(address => bool) public isBot;
    uint256 public tradingEnabledAt;

    // ============ FEES ============
    uint256 public totalFeesCollected;
    
    // ============ EVENTS ============
    event TaxUpdated(uint256 buyTax, uint256 sellTax);
    event AntiBotToggled(bool enabled);
    event MaxTxUpdated(uint256 amount);
    event MaxWalletUpdated(uint256 amount);
    event BotMarked(address indexed bot);
    event BotUnmarked(address indexed bot);
    event TradingEnabled(uint256 timestamp);
    event FeesCollected(uint256 amount);

    constructor(
        string memory name,
        string memory symbol,
        uint256 initialSupply,
        address _taxWallet,
        address initialOwner
    ) ERC20(name, symbol) ERC20Permit(name) Ownable(initialOwner) {
        require(_taxWallet != address(0), "Tax wallet cannot be zero");
        
        taxWallet = _taxWallet;
        maxTxAmount = initialSupply / 100; // 1% of supply
        maxWalletAmount = initialSupply / 50; // 2% of supply
        
        _mint(initialOwner, initialSupply);
    }

    // ============ TRADING CONTROL ============

    /// @notice Enable trading (call after launch setup)
    function enableTrading() external onlyOwner {
        require(tradingEnabledAt == 0, "Trading already enabled");
        tradingEnabledAt = block.timestamp;
        antiBotEnabled = true;
        emit TradingEnabled(block.timestamp);
    }

    // ============ TAX FUNCTIONS ============

    /// @notice Update buy/sell tax (max 10%)
    function setTaxes(uint256 _buyTax, uint256 _sellTax) external onlyOwner {
        require(_buyTax <= MAX_TAX && _sellTax <= MAX_TAX, "Tax too high");
        buyTax = _buyTax;
        sellTax = _sellTax;
        emit TaxUpdated(_buyTax, _sellTax);
    }

    /// @notice Update tax wallet
    function setTaxWallet(address _taxWallet) external onlyOwner {
        require(_taxWallet != address(0), "Cannot be zero address");
        taxWallet = _taxWallet;
    }

    /// @notice Withdraw accumulated ETH fees
    function withdrawFees() external onlyOwner {
        uint256 balance = address(this).balance;
        require(balance > 0, "No fees to withdraw");
        totalFeesCollected += balance;
        (bool success, ) = payable(owner()).call{value: balance}("");
        require(success, "Transfer failed");
        emit FeesCollected(balance);
    }

    // ============ ANTI-BOT FUNCTIONS ============

    /// @notice Toggle anti-bot protection
    function setAntiBot(bool _enabled) external onlyOwner {
        antiBotEnabled = _enabled;
        emit AntiBotToggled(_enabled);
    }

    /// @notice Update max transaction amount
    function setMaxTxAmount(uint256 _amount) external onlyOwner {
        require(_amount > 0, "Cannot be zero");
        maxTxAmount = _amount;
        emit MaxTxUpdated(_amount);
    }

    /// @notice Update max wallet amount
    function setMaxWalletAmount(uint256 _amount) external onlyOwner {
        require(_amount > 0, "Cannot be zero");
        maxWalletAmount = _amount;
        emit MaxWalletUpdated(_amount);
    }

    /// @notice Mark address as bot
    function markBot(address _bot) external onlyOwner {
        require(_bot != address(0), "Cannot be zero address");
        isBot[_bot] = true;
        emit BotMarked(_bot);
    }

    /// @notice Unmark address as bot
    function unmarkBot(address _bot) external onlyOwner {
        require(_bot != address(0), "Cannot be zero address");
        isBot[_bot] = false;
        emit BotUnmarked(_bot);
    }

    /// @notice Mark multiple bots at once
    function markBots(address[] calldata _bots) external onlyOwner {
        for (uint256 i = 0; i < _bots.length; i++) {
            require(_bots[i] != address(0), "Cannot be zero address");
            isBot[_bots[i]] = true;
            emit BotMarked(_bots[i]);
        }
    }

    /// @notice Unmark multiple bots at once
    function unmarkBots(address[] calldata _bots) external onlyOwner {
        for (uint256 i = 0; i < _bots.length; i++) {
            require(_bots[i] != address(0), "Cannot be zero address");
            isBot[_bots[i]] = false;
            emit BotUnmarked(_bots[i]);
        }
    }

    // ============ EXEMPTIONS ============

    mapping(address => bool) private _isExcludedFromTax;
    mapping(address => bool) private _isExcludedFromLimits;

    /// @notice Exclude address from tax
    function excludeFromTax(address _address, bool _excluded) external onlyOwner {
        _isExcludedFromTax[_address] = _excluded;
    }

    /// @notice Exclude address from limits
    function excludeFromLimits(address _address, bool _excluded) external onlyOwner {
        _isExcludedFromLimits[_address] = _excluded;
    }

    /// @notice Check if address is excluded from tax
    function isExcludedFromTax(address _address) external view returns (bool) {
        return _isExcludedFromTax[_address];
    }

    /// @notice Check if address is excluded from limits
    function isExcludedFromLimits(address _address) external view returns (bool) {
        return _isExcludedFromLimits[_address];
    }

    // ============ TRANSFER HOOK ============

    function _update(
        address from,
        address to,
        uint256 amount
    ) internal override(ERC20) {
        // Anti-bot check
        if (antiBotEnabled && isBot[from]) {
            revert("Bot detected");
        }

        // Trading not enabled - only owner can transfer
        if (tradingEnabledAt == 0) {
            require(
                from == owner() || to == owner(),
                "Trading not enabled"
            );
        }

        // Limits only apply to non-excluded addresses
        if (!_isExcludedFromLimits[from] && !_isExcludedFromLimits[to]) {
            require(amount <= maxTxAmount, "Exceeds max tx amount");
            
            // Max wallet check (only for buys)
            if (to != address(0) && to != address(this)) {
                require(
                    balanceOf(to) + amount <= maxWalletAmount,
                    "Exceeds max wallet"
                );
            }
        }

        // Tax logic
        bool takeFee = true;
        if (_isExcludedFromTax[from] || _isExcludedFromTax[to] || 
            from == address(this) || to == address(this)) {
            takeFee = false;
        }

        if (takeFee && amount > 0) {
            uint256 taxAmount = 0;
            
            // Determine if buy or sell
            if (from == uniswapV2Pair()) {
                // Buy
                taxAmount = (amount * buyTax) / 10000;
            } else if (to == uniswapV2Pair()) {
                // Sell
                taxAmount = (amount * sellTax) / 10000;
            }

            if (taxAmount > 0) {
                super._update(from, address(this), taxAmount);
                amount -= taxAmount;
            }
        }

        super._update(from, to, amount);
    }

    // ============ VIEW FUNCTIONS ============

    /// @notice Get token info
    function getTokenInfo() external view returns (
        string memory name_,
        string memory symbol_,
        uint256 totalSupply_,
        uint256 buyTax_,
        uint256 sellTax_,
        uint256 maxTx_,
        uint256 maxWallet_,
        bool tradingEnabled_
    ) {
        return (
            name(),
            symbol(),
            totalSupply(),
            buyTax,
            sellTax,
            maxTxAmount,
            maxWalletAmount,
            tradingEnabledAt > 0
        );
    }

    // ============ RECEIVE ETH ============

    receive() external payable {}
    fallback() external payable {}
}

// ============ UNISWAP V2 PAIR INTERFACE ============

interface IUniswapV2Pair {
    function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    function token0() external view returns (address);
    function token1() external view returns (address);
}

interface IUniswapV2Factory {
    function createPair(address tokenA, address tokenB) external returns (address pair);
}

interface IUniswapV2Router02 {
    function factory() external pure returns (address);
    function WETH() external pure returns (address);
    function swapExactTokensForETHSupportingFeeOnTransferTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external;
    function swapExactETHForTokensSupportingFeeOnTransferTokens(
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external payable;
}