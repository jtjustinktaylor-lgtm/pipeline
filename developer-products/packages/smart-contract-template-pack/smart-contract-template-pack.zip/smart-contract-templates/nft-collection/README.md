# NexGen NFT Collection Template

> **Production-ready NFT collection with reveal, whitelist, and advanced features.**
> Perfect for PFP projects, art collections, and gaming assets.

---

## 🚀 Features

- ✅ **ERC-721 Standard** — Full compliance with OpenZeppelin
- ✅ **Whitelist Mint** — Early access with merkle proofs
- ✅ **Public Mint** — Open minting phase
- ✅ **Airdrop** — Batch airdrop to multiple addresses
- ✅ **Delayed Reveal** — Reveal metadata after mint
- ✅ **Royalties** — EIP-2981 compliant royalties
- ✅ **Pausable** — Emergency pause capability
- ✅ **Reentrancy Guard** — Protection against reentrancy attacks
- ✅ **Enumerable** — Query all tokens and owners
- ✅ **URI Storage** — Individual token metadata

---

## 📦 What's Included

```
nft-collection/
├── contracts/
│   └── NexGenNFT.sol            # Main contract (14KB)
├── scripts/
│   └── deploy.js                # Deployment script
├── test/
│   └── NexGenNFT.test.js        # 100% test coverage
├── metadata/
│   ├── 0.json                   # Sample metadata
│   └── example-metadata.json    # Metadata template
├── hardhat.config.js            # Hardhat configuration
├── package.json                 # Dependencies
├── .env.example                 # Environment variables template
└── README.md                    # This file
```

---

## ⚡ Quick Start

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your keys
```

### 3. Compile Contracts

```bash
npx hardhat compile
```

### 4. Run Tests

```bash
npx hardhat test
```

### 5. Deploy

```bash
# Local
npx hardhat run scripts/deploy.js

# Testnet (Goerli)
npx hardhat run scripts/deploy.js --network goerli

# Mainnet
npx hardhat run scripts/deploy.js --network mainnet
```

---

## 🔧 Configuration

### Constructor Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `name` | string | Collection name (e.g., "Cool Cats") |
| `symbol` | string | Collection symbol (e.g., "COOL") |
| `baseURI` | string | Base URI for revealed metadata |
| `notRevealedURI` | string | URI before reveal (placeholder) |
| `maxSupply` | uint256 | Maximum number of NFTs |
| `royaltyWallet` | address | Wallet to receive royalties |
| `initialOwner` | address | Contract owner address |

### Example Deployment

```javascript
const nft = await NexGenNFT.deploy(
    "Cool Cats",                                          // name
    "COOL",                                               // symbol
    "ipfs://QmYourCID/",                                  // baseURI
    "ipfs://QmRevealPlaceholder/",                        // notRevealedURI
    10000,                                                // maxSupply
    "0xRoyaltyWallet...",                                 // royaltyWallet
    "0xOwner..."                                          // owner
);
```

---

## 🎨 Minting Phases

### Phase 1: Whitelist (Early Access)

```javascript
// Add addresses to whitelist
await nft.addToWhitelist("0xAddress1...");
await nft.addMultipleToWhitelist(["0xAddr1...", "0xAddr2..."]);

// Or set merkle root for proof-based whitelist
await nft.setMerkleRoot("0xMerkleRoot...");

// Activate whitelist
await nft.setWhitelistActive(true);
```

**Whitelist Mint:**
```javascript
// Simple whitelist mint
await nft.whitelistMint(2, { value: ethers.parseEther("0.02") });

// Merkle proof whitelist mint
await nft.whitelistMintWithProof(2, proof, { value: ethers.parseEther("0.02") });
```

### Phase 2: Public Mint

```javascript
// Activate public mint
await nft.setPublicActive(true);

// Public mint
await nft.publicMint(3, { value: ethers.parseEther("0.06") });
```

### Phase 3: Airdrop

```javascript
// Single airdrop
await nft.airdrop("0xRecipient...", 5);

// Batch airdrop
await nft.batchAirdrop(
    ["0xAddr1...", "0xAddr2..."],
    [3, 2]
);
```

---

## 🎭 Reveal System

### Pre-Reveal

Before reveal, all tokens show the `notRevealedURI` (placeholder image).

```javascript
// Set placeholder URI
await nft.setNotRevealedURI("ipfs://QmPlaceholder/");
```

### Reveal

```javascript
// Reveal the collection
await nft.reveal();

// Update base URI if needed
await nft.setBaseURI("ipfs://QmNewCID/");
```

---

## 💰 Royalties (EIP-2981)

### Configure Royalties

```javascript
// Set 5% royalty
await nft.setRoyalty(500, "0xRoyaltyWallet...");

// Set 7.5% royalty
await nft.setRoyalty(750, "0xRoyaltyWallet...");
```

### Royalty Info

```javascript
const [receiver, amount] = await nft.royaltyInfo(tokenId, salePrice);
```

---

## 🛡️ Security Features

### Access Control

- **Owner-only functions** — Admin operations protected
- **Ownership transfer** — Secure ownership handoff
- **Renounce ownership** — Make fully decentralized

### Mint Protection

- **Max per wallet** — Limit holdings per address
- **Max per transaction** — Limit mints per transaction
- **Supply cap** — Hard limit on total supply
- **Phase control** — Separate whitelist/public phases

### Contract Security

- **Reentrancy guard** — Prevent reentrancy attacks
- **Pausable** — Emergency pause capability
- **Safe transfers** — ERC721 safe transfer checks

---

## 📊 Metadata Format

### Standard Metadata

```json
{
    "name": "NexGen NFT #1",
    "description": "A unique digital collectible",
    "image": "ipfs://QmYourCID/1.png",
    "attributes": [
        {
            "trait_type": "Background",
            "value": "Blue"
        },
        {
            "trait_type": "Eyes",
            "value": "Laser"
        },
        {
            "trait_type": "Rarity",
            "value": "Legendary"
        }
    ],
    "external_url": "https://yournft.com/1"
}
```

### Metadata Template

```json
{
    "name": "NexGen NFT #{id}",
    "description": "Description of your collection",
    "image": "ipfs://YOUR_CID/{id}.png",
    "attributes": [
        {
            "trait_type": "Trait Name",
            "value": "Trait Value"
        }
    ],
    "external_url": "https://yoursite.com/{id}"
}
```

---

## 🖼️ Image Preparation

### Recommended Specs

| Spec | Value |
|------|-------|
| **Format** | PNG or GIF |
| **Size** | 1000x1000px (minimum) |
| **Resolution** | 72 DPI |
| **File size** | < 5MB per image |
| **Naming** | 0.png, 1.png, 2.png, etc. |

### Upload to IPFS

1. **Pinata** — https://pinata.cloud
2. **NFT.Storage** — https://nft.storage
3. **Infura IPFS** — https://infura.io/product/ipfs

---

## 🧪 Testing

### Run All Tests

```bash
npx hardhat test
```

### Test Coverage

```bash
npx hardhat coverage
```

### Test Scenarios

- ✅ Collection deployment
- ✅ Whitelist minting
- ✅ Public minting
- ✅ Airdrop functionality
- ✅ Batch airdrop
- ✅ Reveal mechanism
- ✅ Royalty configuration
- ✅ Max supply enforcement
- ✅ Max per wallet enforcement
- ✅ Phase toggling
- ✅ Pausable functionality
- ✅ Fund withdrawal

---

## 🔗 Deployment Networks

### Supported Networks

| Network | Chain ID | RPC |
|---------|----------|-----|
| Ethereum Mainnet | 1 | https://mainnet.infura.io/v3/... |
| Goerli Testnet | 5 | https://goerli.infura.io/v3/... |
| Paxeer Network | 125 | https://public-rpc.paxeer.app/evm/reference |
| BSC Mainnet | 56 | https://bsc-dataseed.binance.org/ |
| Polygon | 137 | https://polygon-rpc.com/ |

---

## 📈 Launch Checklist

### Pre-Launch

- [ ] Create artwork (1000+ images)
- [ ] Upload images to IPFS
- [ ] Generate metadata JSON files
- [ ] Upload metadata to IPFS
- [ ] Deploy contract
- [ ] Configure whitelist
- [ ] Set prices
- [ ] Test minting on testnet

### Launch

- [ ] Activate whitelist phase
- [ ] Monitor whitelist minting
- [ ] Activate public phase
- [ ] Monitor public minting
- [ ] Handle any issues

### Post-Launch

- [ ] Reveal collection
- [ ] Verify contract on explorer
- [ ] Submit to OpenSea
- [ ] Submit to other marketplaces
- [ ] Build community

---

## 💡 Customization Guide

### Add Staking Rewards

```solidity
// Add staking function
function stake(uint256 tokenId) external {
    // Lock token and distribute rewards
}
```

### Add Breeding Mechanics

```solidity
// Add breeding function
function breed(uint256 token1, uint256 token2) external {
    // Create new NFT from two parents
}
```

### Add Upgrade Mechanics

```solidity
// Add upgrade function
function upgrade(uint256 tokenId) external {
    // Enhance NFT attributes
}
```

---

## 📚 Resources

- [OpenZeppelin Docs](https://docs.openzeppelin.com/)
- [ERC-721 Standard](https://eips.ethereum.org/EIPS/eip-721)
- [EIP-2981 (Royalties)](https://eips.ethereum.org/EIPS/eip-2981)
- [IPFS Docs](https://docs.ipfs.io/)
- [Metadata Standards](https://docs.opensea.io/docs/metadata-standards)

---

## 🆘 Support

- **Documentation:** [docs.nexgenai.dev](https://docs.nexgenai.dev)
- **Discord:** [discord.gg/nexgenai](https://discord.gg/nexgenai)
- **Email:** support@nexgenai.dev

---

## 📄 License

MIT License — See [LICENSE](LICENSE) for details.

---

## ⚠️ Disclaimer

This template is provided as-is for educational purposes. Always:
- Get a professional audit before mainnet deployment
- Test thoroughly on testnets first
- Understand the risks of smart contract deployment
- Comply with local regulations

---

**Built by NexGen AI — Save 40+ hours of development time.**