// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import "@openzeppelin/contracts/token/ERC721/extensions/ERC721Enumerable.sol";
import "@openzeppelin/contracts/token/ERC721/extensions/ERC721URIStorage.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";

/// @title NexGen NFT Collection
/// @notice Production-ready NFT collection with reveal, whitelist, and advanced features
/// @dev Perfect for PFP projects, art collections, and gaming assets
contract NexGenNFT is ERC721, ERC721Enumerable, ERC721URIStorage, Ownable, ReentrancyGuard, Pausable {
    // ============ SUPPLY ============
    uint256 public maxSupply = 10000;
    uint256 public totalMinted;
    uint256 public maxPerWallet = 5;
    uint256 public maxPerTransaction = 3;

    // ============ PRICING ============
    uint256 public whitelistPrice = 0.01 ether;
    uint256 public publicPrice = 0.02 ether;
    uint256 public airdropPrice = 0; // Free for airdrops

    // ============ PHASES ============
    bool public whitelistActive = false;
    bool public publicActive = false;
    uint256 public whitelistStartTime;
    uint256 public publicStartTime;

    // ============ WHITELIST ============
    mapping(address => bool) public whitelist;
    mapping(address => uint256) public whitelistMinted;
    bytes32 public merkleRoot;
    mapping(address => bool) public whitelistUsed;

    // ============ REVEAL ============
    bool public revealed = false;
    string private baseURI;
    string private notRevealedURI;

    // ============ ROYALTIES ============
    uint256 public royaltyFee = 500; // 5% (in basis points)
    address public royaltyWallet;

    // ============ FUNDS ============
    uint256 public totalFundsCollected;

    // ============ METADATA ============
    string public name;
    string public symbol;
    string public description;
    string public image;
    string public externalUrl;

    // ============ EVENTS ============
    event Minted(address indexed to, uint256 indexed tokenId, uint256 price);
    event WhitelistToggled(bool active);
    event PublicToggled(bool active);
    event Revealed(string baseURI);
    event BaseURIUpdated(string baseURI);
    event NotRevealedURIUpdated(string uri);
    event RoyaltyUpdated(uint256 fee, address wallet);
    event MaxSupplyUpdated(uint256 supply);
    event MaxPerWalletUpdated(uint256 amount);
    event PricesUpdated(uint256 whitelistPrice, uint256 publicPrice);
    event FundsWithdrawn(uint256 amount);
    event Airdropped(address indexed to, uint256 indexed tokenId);

    constructor(
        string memory _name,
        string memory _symbol,
        string memory _baseURI,
        string memory _notRevealedURI,
        uint256 _maxSupply,
        address _royaltyWallet,
        address initialOwner
    ) ERC721(_name, _symbol) Ownable(initialOwner) {
        name = _name;
        symbol = _symbol;
        baseURI = _baseURI;
        notRevealedURI = _notRevealedURI;
        maxSupply = _maxSupply;
        royaltyWallet = _royaltyWallet;
    }

    // ============ WHITELIST MINT ============

    /// @notice Mint with whitelist (early access)
    function whitelistMint(uint256 quantity) external payable nonReentrant whenNotPaused {
        require(whitelistActive, "Whitelist not active");
        require(whitelist[msg.sender], "Not whitelisted");
        require(quantity > 0 && quantity <= maxPerTransaction, "Invalid quantity");
        require(whitelistMinted[msg.sender] + quantity <= maxPerWallet, "Exceeds max per wallet");
        require(totalMinted + quantity <= maxSupply, "Exceeds max supply");
        require(msg.value >= whitelistPrice * quantity, "Insufficient payment");

        whitelistMinted[msg.sender] += quantity;

        for (uint256 i = 0; i < quantity; i++) {
            uint256 tokenId = totalMinted + 1;
            _safeMint(msg.sender, tokenId);
            totalMinted++;
            emit Minted(msg.sender, tokenId, whitelistPrice);
        }
    }

    /// @notice Mint with merkle proof whitelist
    function whitelistMintWithProof(
        uint256 quantity,
        bytes32[] calldata proof
    ) external payable nonReentrant whenNotPaused {
        require(whitelistActive, "Whitelist not active");
        require(quantity > 0 && quantity <= maxPerTransaction, "Invalid quantity");
        require(whitelistMinted[msg.sender] + quantity <= maxPerWallet, "Exceeds max per wallet");
        require(totalMinted + quantity <= maxSupply, "Exceeds max supply");
        require(msg.value >= whitelistPrice * quantity, "Insufficient payment");

        // Verify merkle proof
        bytes32 leaf = keccak256(abi.encodePacked(msg.sender));
        require(_verifyProof(proof, merkleRoot, leaf), "Invalid proof");

        whitelistMinted[msg.sender] += quantity;

        for (uint256 i = 0; i < quantity; i++) {
            uint256 tokenId = totalMinted + 1;
            _safeMint(msg.sender, tokenId);
            totalMinted++;
            emit Minted(msg.sender, tokenId, whitelistPrice);
        }
    }

    // ============ PUBLIC MINT ============

    /// @notice Public mint
    function publicMint(uint256 quantity) external payable nonReentrant whenNotPaused {
        require(publicActive, "Public mint not active");
        require(quantity > 0 && quantity <= maxPerTransaction, "Invalid quantity");
        require(balanceOf(msg.sender) + quantity <= maxPerWallet, "Exceeds max per wallet");
        require(totalMinted + quantity <= maxSupply, "Exceeds max supply");
        require(msg.value >= publicPrice * quantity, "Insufficient payment");

        for (uint256 i = 0; i < quantity; i++) {
            uint256 tokenId = totalMinted + 1;
            _safeMint(msg.sender, tokenId);
            totalMinted++;
            emit Minted(msg.sender, tokenId, publicPrice);
        }
    }

    // ============ AIRDROP ============

    /// @notice Airdrop NFT to address (owner only)
    function airdrop(address to, uint256 quantity) external onlyOwner whenNotPaused {
        require(totalMinted + quantity <= maxSupply, "Exceeds max supply");
        require(to != address(0), "Cannot mint to zero address");

        for (uint256 i = 0; i < quantity; i++) {
            uint256 tokenId = totalMinted + 1;
            _safeMint(to, tokenId);
            totalMinted++;
            emit Airdropped(to, tokenId);
        }
    }

    /// @notice Batch airdrop to multiple addresses
    function batchAirdrop(address[] calldata recipients, uint256[] calldata quantities) external onlyOwner whenNotPaused {
        require(recipients.length == quantities.length, "Length mismatch");
        require(recipients.length > 0, "Empty arrays");

        for (uint256 i = 0; i < recipients.length; i++) {
            require(totalMinted + quantities[i] <= maxSupply, "Exceeds max supply");
            require(recipients[i] != address(0), "Cannot mint to zero address");

            for (uint256 j = 0; j < quantities[i]; j++) {
                uint256 tokenId = totalMinted + 1;
                _safeMint(recipients[i], tokenId);
                totalMinted++;
                emit Airdropped(recipients[i], tokenId);
            }
        }
    }

    // ============ REVEAL ============

    /// @notice Reveal the collection
    function reveal() external onlyOwner {
        require(!revealed, "Already revealed");
        revealed = true;
        emit Revealed(baseURI);
    }

    /// @notice Update base URI (after reveal)
    function setBaseURI(string calldata _baseURI) external onlyOwner {
        baseURI = _baseURI;
        emit BaseURIUpdated(_baseURI);
    }

    /// @notice Update not revealed URI
    function setNotRevealedURI(string calldata _uri) external onlyOwner {
        notRevealedURI = _uri;
        emit NotRevealedURIUpdated(_uri);
    }

    // ============ WHITELIST MANAGEMENT ============

    /// @notice Toggle whitelist phase
    function setWhitelistActive(bool _active) external onlyOwner {
        whitelistActive = _active;
        if (_active) {
            whitelistStartTime = block.timestamp;
        }
        emit WhitelistToggled(_active);
    }

    /// @notice Toggle public phase
    function setPublicActive(bool _active) external onlyOwner {
        publicActive = _active;
        if (_active) {
            publicStartTime = block.timestamp;
        }
        emit PublicToggled(_active);
    }

    /// @notice Add address to whitelist
    function addToWhitelist(address _address) external onlyOwner {
        require(_address != address(0), "Cannot be zero address");
        whitelist[_address] = true;
    }

    /// @notice Add multiple addresses to whitelist
    function addMultipleToWhitelist(address[] calldata _addresses) external onlyOwner {
        for (uint256 i = 0; i < _addresses.length; i++) {
            require(_addresses[i] != address(0), "Cannot be zero address");
            whitelist[_addresses[i]] = true;
        }
    }

    /// @notice Remove address from whitelist
    function removeFromWhitelist(address _address) external onlyOwner {
        require(_address != address(0), "Cannot be zero address");
        whitelist[_address] = false;
    }

    /// @notice Set merkle root for whitelist proofs
    function setMerkleRoot(bytes32 _merkleRoot) external onlyOwner {
        merkleRoot = _merkleRoot;
    }

    // ============ CONFIGURATION ============

    /// @notice Update max supply
    function setMaxSupply(uint256 _maxSupply) external onlyOwner {
        require(_maxSupply >= totalMinted, "Cannot be less than minted");
        maxSupply = _maxSupply;
        emit MaxSupplyUpdated(_maxSupply);
    }

    /// @notice Update max per wallet
    function setMaxPerWallet(uint256 _amount) external onlyOwner {
        require(_amount > 0, "Cannot be zero");
        maxPerWallet = _amount;
        emit MaxPerWalletUpdated(_amount);
    }

    /// @notice Update max per transaction
    function setMaxPerTransaction(uint256 _amount) external onlyOwner {
        require(_amount > 0, "Cannot be zero");
        maxPerTransaction = _amount;
    }

    /// @notice Update prices
    function setPrices(uint256 _whitelistPrice, uint256 _publicPrice) external onlyOwner {
        whitelistPrice = _whitelistPrice;
        publicPrice = _publicPrice;
        emit PricesUpdated(_whitelistPrice, _publicPrice);
    }

    /// @notice Update royalties
    function setRoyalty(uint256 _fee, address _wallet) external onlyOwner {
        require(_fee <= 1000, "Fee too high"); // Max 10%
        require(_wallet != address(0), "Cannot be zero address");
        royaltyFee = _fee;
        royaltyWallet = _wallet;
        emit RoyaltyUpdated(_fee, _wallet);
    }

    // ============ FUNDS ============

    /// @notice Withdraw accumulated funds
    function withdraw() external onlyOwner nonReentrant {
        uint256 balance = address(this).balance;
        require(balance > 0, "No funds to withdraw");
        totalFundsCollected += balance;
        (bool success, ) = payable(owner()).call{value: balance}("");
        require(success, "Transfer failed");
        emit FundsWithdrawn(balance);
    }

    // ============ PAUSE ============

    /// @notice Pause all minting
    function pause() external onlyOwner {
        _pause();
    }

    /// @notice Unpause all minting
    function unpause() external onlyOwner {
        _unpause();
    }

    // ============ VIEW FUNCTIONS ============

    /// @notice Get collection info
    function getCollectionInfo() external view returns (
        string memory name_,
        string memory symbol_,
        uint256 maxSupply_,
        uint256 totalMinted_,
        uint256 whitelistPrice_,
        uint256 publicPrice_,
        bool whitelistActive_,
        bool publicActive_,
        bool revealed_
    ) {
        return (
            name,
            symbol,
            maxSupply,
            totalMinted,
            whitelistPrice,
            publicPrice,
            whitelistActive,
            publicActive,
            revealed
        );
    }

    /// @notice Get mint progress
    function getMintProgress() external view returns (
        uint256 minted,
        uint256 remaining,
        uint256 percentage
    ) {
        minted = totalMinted;
        remaining = maxSupply - totalMinted;
        percentage = (totalMinted * 10000) / maxSupply; // Basis points
    }

    /// @notice Check if address can mint
    function canMint(address _address, bool isWhitelist) external view returns (bool) {
        if (isWhitelist) {
            return whitelistActive && whitelist[_address] && whitelistMinted[_address] < maxPerWallet;
        } else {
            return publicActive && balanceOf(_address) < maxPerWallet;
        }
    }

    // ============ INTERNAL FUNCTIONS ============

    function _verifyProof(
        bytes32[] calldata proof,
        bytes32 root,
        bytes32 leaf
    ) internal pure returns (bool) {
        bytes32 computedHash = leaf;
        for (uint256 i = 0; i < proof.length; i++) {
            bytes32 proofElement = proof[i];
            if (computedHash <= proofElement) {
                computedHash = keccak256(abi.encodePacked(computedHash, proofElement));
            } else {
                computedHash = keccak256(abi.encodePacked(proofElement, computedHash));
            }
        }
        return computedHash == root;
    }

    // ============ OVERRIDES ============

    function _baseURI() internal view override returns (string memory) {
        if (revealed) {
            return baseURI;
        }
        return notRevealedURI;
    }

    function tokenURI(uint256 tokenId) public view override(ERC721, ERC721URIStorage) returns (string memory) {
        return super.tokenURI(tokenId);
    }

    function supportsInterface(bytes4 interfaceId) public view override(ERC721, ERC721Enumerable, ERC721URIStorage) returns (bool) {
        return super.supportsInterface(interfaceId);
    }

    function _update(address to, uint256 tokenId, address auth) internal override(ERC721, ERC721Enumerable) returns (address) {
        return super._update(to, tokenId, auth);
    }

    function _increaseBalance(address account, uint128 value) internal override(ERC721, ERC721Enumerable) {
        super._increaseBalance(account, value);
    }

    // ============ RECEIVE ETH ============

    receive() external payable {}
    fallback() external payable {}
}