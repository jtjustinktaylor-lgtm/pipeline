// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/// @title NexGen Vesting Contract
/// @notice Production-ready token vesting with flexible schedules and cliff
/// @dev Perfect for team tokens, investor allocations, and advisor vesting
contract NexGenVesting is Ownable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    // ============ TOKEN ============
    IERC20 public vestingToken;

    // ============ VESTING SCHEDULE ============
    struct VestingSchedule {
        address beneficiary;        // Beneficiary address
        uint256 totalAmount;        // Total tokens to vest
        uint256 startTime;          // Vesting start time
        uint256 cliffDuration;      // Cliff period (seconds)
        uint256 vestingDuration;    // Total vesting duration (seconds)
        uint256 released;           // Amount already released
        bool revocable;             // Whether schedule is revocable
        bool revoked;               // Whether schedule has been revoked
        string category;            // Category (team, investor, advisor, etc.)
    }

    mapping(bytes32 => VestingSchedule) public vestingSchedules;
    mapping(address => bytes32[]) public beneficiarySchedules;
    bytes32[] public allScheduleIds;
    mapping(bytes32 => bool) public scheduleExists;

    // ============ GLOBAL SETTINGS ============
    uint256 public totalAllocated;
    uint256 public totalReleased;
    uint256 public totalRevoked;

    // ============ EVENTS ============
    event VestingScheduleCreated(
        bytes32 indexed scheduleId,
        address indexed beneficiary,
        uint256 totalAmount,
        uint256 startTime,
        uint256 cliffDuration,
        uint256 vestingDuration,
        bool revocable,
        string category
    );
    event TokensReleased(bytes32 indexed scheduleId, address indexed beneficiary, uint256 amount);
    event VestingRevoked(bytes32 indexed scheduleId, uint256 unreleasedAmount);
    event ScheduleTransferred(bytes32 indexed scheduleId, address indexed oldBeneficiary, address indexed newBeneficiary);

    constructor(address _vestingToken, address initialOwner) Ownable(initialOwner) {
        require(_vestingToken != address(0), "Token cannot be zero");
        vestingToken = IERC20(_vestingToken);
    }

    // ============ CREATE SCHEDULES ============

    /// @notice Create a vesting schedule
    /// @param beneficiary Address of the beneficiary
    /// @param totalAmount Total amount of tokens to vest
    /// @param startTime Vesting start timestamp
    /// @param cliffDuration Cliff period in seconds
    /// @param vestingDuration Total vesting duration in seconds
    /// @param revocable Whether the vesting is revocable
    /// @param category Category label (team, investor, advisor, etc.)
    function createVestingSchedule(
        address beneficiary,
        uint256 totalAmount,
        uint256 startTime,
        uint256 cliffDuration,
        uint256 vestingDuration,
        bool revocable,
        string calldata category
    ) external onlyOwner returns (bytes32 scheduleId) {
        require(beneficiary != address(0), "Beneficiary cannot be zero");
        require(totalAmount > 0, "Amount must be greater than 0");
        require(vestingDuration > 0, "Duration must be greater than 0");
        require(cliffDuration <= vestingDuration, "Cliff exceeds duration");
        require(startTime >= block.timestamp, "Start time must be in future");
        require(vestingToken.balanceOf(address(this)) >= totalAmount + totalAllocated, "Insufficient balance");

        // Generate unique schedule ID
        scheduleId = keccak256(abi.encodePacked(
            beneficiary,
            totalAmount,
            startTime,
            block.timestamp
        ));

        require(!scheduleExists[scheduleId], "Schedule already exists");

        vestingSchedules[scheduleId] = VestingSchedule({
            beneficiary: beneficiary,
            totalAmount: totalAmount,
            startTime: startTime,
            cliffDuration: cliffDuration,
            vestingDuration: vestingDuration,
            released: 0,
            revocable: revocable,
            revoked: false,
            category: category
        });

        beneficiarySchedules[beneficiary].push(scheduleId);
        allScheduleIds.push(scheduleId);
        scheduleExists[scheduleId] = true;
        totalAllocated += totalAmount;

        emit VestingScheduleCreated(
            scheduleId,
            beneficiary,
            totalAmount,
            startTime,
            cliffDuration,
            vestingDuration,
            revocable,
            category
        );

        return scheduleId;
    }

    /// @notice Create multiple vesting schedules at once
    function createMultipleSchedules(
        address[] calldata beneficiaries,
        uint256[] calldata amounts,
        uint256[] calldata startTimes,
        uint256[] calldata cliffDurations,
        uint256[] calldata vestingDurations,
        bool[] calldata revocables,
        string[] calldata categories
    ) external onlyOwner returns (bytes32[] memory scheduleIds) {
        uint256 length = beneficiaries.length;
        require(length == amounts.length, "Length mismatch");
        require(length == startTimes.length, "Length mismatch");
        require(length == cliffDurations.length, "Length mismatch");
        require(length == vestingDurations.length, "Length mismatch");
        require(length == revocables.length, "Length mismatch");
        require(length == categories.length, "Length mismatch");

        scheduleIds = new bytes32[](length);

        for (uint256 i = 0; i < length; i++) {
            scheduleIds[i] = createVestingSchedule(
                beneficiaries[i],
                amounts[i],
                startTimes[i],
                cliffDurations[i],
                vestingDurations[i],
                revocables[i],
                categories[i]
            );
        }

        return scheduleIds;
    }

    // ============ RELEASE ============

    /// @notice Release vested tokens
    function release(bytes32 scheduleId) external nonReentrant {
        require(scheduleExists[scheduleId], "Schedule does not exist");
        VestingSchedule storage schedule = vestingSchedules[scheduleId];
        require(!schedule.revoked, "Schedule revoked");
        require(msg.sender == schedule.beneficiary || msg.sender == owner(), "Not authorized");

        uint256 vestedAmount = _calculateVestedAmount(schedule);
        uint256 releasableAmount = vestedAmount - schedule.released;

        require(releasableAmount > 0, "No tokens to release");

        schedule.released += releasableAmount;
        totalReleased += releasableAmount;

        vestingToken.safeTransfer(schedule.beneficiary, releasableAmount);

        emit TokensReleased(scheduleId, schedule.beneficiary, releasableAmount);
    }

    /// @notice Release all vested tokens for a beneficiary
    function releaseAllForBeneficiary(address beneficiary) external nonReentrant {
        require(beneficiary != address(0), "Beneficiary cannot be zero");

        bytes32[] storage schedules = beneficiarySchedules[beneficiary];
        uint256 totalReleased_ = 0;

        for (uint256 i = 0; i < schedules.length; i++) {
            VestingSchedule storage schedule = vestingSchedules[schedules[i]];
            if (!schedule.revoked) {
                uint256 vestedAmount = _calculateVestedAmount(schedule);
                uint256 releasableAmount = vestedAmount - schedule.released;

                if (releasableAmount > 0) {
                    schedule.released += releasableAmount;
                    totalReleased_ += releasableAmount;
                    emit TokensReleased(schedules[i], beneficiary, releasableAmount);
                }
            }
        }

        require(totalReleased_ > 0, "No tokens to release");

        totalReleased += totalReleased_;
        vestingToken.safeTransfer(beneficiary, totalReleased_);
    }

    // ============ REVOKE ============

    /// @notice Revoke a vesting schedule (if revocable)
    function revoke(bytes32 scheduleId) external onlyOwner {
        require(scheduleExists[scheduleId], "Schedule does not exist");
        VestingSchedule storage schedule = vestingSchedules[scheduleId];
        require(schedule.revocable, "Schedule not revocable");
        require(!schedule.revoked, "Already revoked");

        // Release any vested tokens first
        uint256 vestedAmount = _calculateVestedAmount(schedule);
        uint256 releasableAmount = vestedAmount - schedule.released;

        if (releasableAmount > 0) {
            schedule.released += releasableAmount;
            totalReleased += releasableAmount;
            vestingToken.safeTransfer(schedule.beneficiary, releasableAmount);
            emit TokensReleased(scheduleId, schedule.beneficiary, releasableAmount);
        }

        // Calculate unreleased amount
        uint256 unreleasedAmount = schedule.totalAmount - schedule.released;

        schedule.revoked = true;
        totalRevoked += unreleasedAmount;
        totalAllocated -= schedule.totalAmount;

        emit VestingRevoked(scheduleId, unreleasedAmount);
    }

    /// @notice Revoke all schedules for a beneficiary
    function revokeAllForBeneficiary(address beneficiary) external onlyOwner {
        require(beneficiary != address(0), "Beneficiary cannot be zero");

        bytes32[] storage schedules = beneficiarySchedules[beneficiary];

        for (uint256 i = 0; i < schedules.length; i++) {
            VestingSchedule storage schedule = vestingSchedules[schedules[i]];
            if (schedule.revocable && !schedule.revoked) {
                // Release vested tokens
                uint256 vestedAmount = _calculateVestedAmount(schedule);
                uint256 releasableAmount = vestedAmount - schedule.released;

                if (releasableAmount > 0) {
                    schedule.released += releasableAmount;
                    totalReleased += releasableAmount;
                    vestingToken.safeTransfer(beneficiary, releasableAmount);
                    emit TokensReleased(schedules[i], beneficiary, releasableAmount);
                }

                // Mark as revoked
                uint256 unreleasedAmount = schedule.totalAmount - schedule.released;
                schedule.revoked = true;
                totalRevoked += unreleasedAmount;
                totalAllocated -= schedule.totalAmount;

                emit VestingRevoked(schedules[i], unreleasedAmount);
            }
        }
    }

    // ============ TRANSFER ============

    /// @notice Transfer vesting schedule to new beneficiary
    function transferSchedule(bytes32 scheduleId, address newBeneficiary) external {
        require(scheduleExists[scheduleId], "Schedule does not exist");
        VestingSchedule storage schedule = vestingSchedules[scheduleId];
        require(msg.sender == schedule.beneficiary, "Not authorized");
        require(!schedule.revoked, "Schedule revoked");
        require(newBeneficiary != address(0), "New beneficiary cannot be zero");

        // Release any vested tokens to old beneficiary
        uint256 vestedAmount = _calculateVestedAmount(schedule);
        uint256 releasableAmount = vestedAmount - schedule.released;

        if (releasableAmount > 0) {
            schedule.released += releasableAmount;
            totalReleased += releasableAmount;
            vestingToken.safeTransfer(schedule.beneficiary, releasableAmount);
            emit TokensReleased(scheduleId, schedule.beneficiary, releasableAmount);
        }

        // Update beneficiary
        address oldBeneficiary = schedule.beneficiary;
        schedule.beneficiary = newBeneficiary;

        // Update mappings
        beneficiarySchedules[newBeneficiary].push(scheduleId);

        emit ScheduleTransferred(scheduleId, oldBeneficiary, newBeneficiary);
    }

    // ============ VIEW FUNCTIONS ============

    /// @notice Calculate vested amount for a schedule
    function _calculateVestedAmount(VestingSchedule storage schedule) internal view returns (uint256) {
        if (block.timestamp < schedule.startTime) {
            return 0;
        }

        uint256 elapsed = block.timestamp - schedule.startTime;

        // Check cliff
        if (elapsed < schedule.cliffDuration) {
            return 0;
        }

        // Calculate vested amount
        if (elapsed >= schedule.vestingDuration) {
            return schedule.totalAmount;
        }

        return (schedule.totalAmount * elapsed) / schedule.vestingDuration;
    }

    /// @notice Get vested amount for a schedule
    function getVestedAmount(bytes32 scheduleId) external view returns (uint256) {
        require(scheduleExists[scheduleId], "Schedule does not exist");
        VestingSchedule storage schedule = vestingSchedules[scheduleId];
        return _calculateVestedAmount(schedule);
    }

    /// @notice Get releasable amount for a schedule
    function getReleasableAmount(bytes32 scheduleId) external view returns (uint256) {
        require(scheduleExists[scheduleId], "Schedule does not exist");
        VestingSchedule storage schedule = vestingSchedules[scheduleId];
        if (schedule.revoked) return 0;
        uint256 vestedAmount = _calculateVestedAmount(schedule);
        return vestedAmount - schedule.released;
    }

    /// @notice Get schedule details
    function getScheduleDetails(bytes32 scheduleId) external view returns (
        address beneficiary,
        uint256 totalAmount,
        uint256 startTime,
        uint256 cliffDuration,
        uint256 vestingDuration,
        uint256 released,
        bool revocable,
        bool revoked,
        string memory category,
        uint256 vestedAmount,
        uint256 releasableAmount
    ) {
        require(scheduleExists[scheduleId], "Schedule does not exist");
        VestingStorage storage schedule = vestingSchedules[scheduleId];

        uint256 vestedAmount_ = _calculateVestedAmount(schedule);
        uint256 releasableAmount_ = schedule.revoked ? 0 : vestedAmount_ - schedule.released;

        return (
            schedule.beneficiary,
            schedule.totalAmount,
            schedule.startTime,
            schedule.cliffDuration,
            schedule.vestingDuration,
            schedule.released,
            schedule.revocable,
            schedule.revoked,
            schedule.category,
            vestedAmount_,
            releasableAmount_
        );
    }

    /// @notice Get all schedules for a beneficiary
    function getSchedulesForBeneficiary(address beneficiary) external view returns (bytes32[] memory) {
        return beneficiarySchedules[beneficiary];
    }

    /// @notice Get all schedule IDs
    function getAllScheduleIds() external view returns (bytes32[] memory) {
        return allScheduleIds;
    }

    /// @notice Get summary statistics
    function getSummary() external view returns (
        uint256 totalAllocated_,
        uint256 totalReleased_,
        uint256 totalRevoked_,
        uint256 totalSchedules_,
        uint256 remainingBalance
    ) {
        return (
            totalAllocated,
            totalReleased,
            totalRevoked,
            allScheduleIds.length,
            vestingToken.balanceOf(address(this))
        );
    }

    /// @notice Get beneficiary summary
    function getBeneficiarySummary(address beneficiary) external view returns (
        uint256 totalVesting,
        uint256 totalReleased_,
        uint256 totalReleasable,
        uint256 scheduleCount
    ) {
        bytes32[] storage schedules = beneficiarySchedules[beneficiary];
        scheduleCount = schedules.length;

        for (uint256 i = 0; i < schedules.length; i++) {
            VestingSchedule storage schedule = vestingSchedules[schedules[i]];
            if (!schedule.revoked) {
                totalVesting += schedule.totalAmount - schedule.released;
                totalReleased_ += schedule.released;

                uint256 vestedAmount = _calculateVestedAmount(schedule);
                uint256 releasableAmount = vestedAmount - schedule.released;
                totalReleasable += releasableAmount;
            }
        }
    }

    // ============ ADMIN ============

    /// @notice Withdraw excess tokens (not allocated)
    function withdrawExcess(uint256 amount) external onlyOwner {
        require(amount > 0, "Amount must be greater than 0");
        uint256 balance = vestingToken.balanceOf(address(this));
        uint256 allocated = totalAllocated - totalReleased - totalRevoked;
        require(balance - allocated >= amount, "Cannot withdraw allocated tokens");
        vestingToken.safeTransfer(owner(), amount);
    }

    // ============ RECEIVE ============

    receive() external payable {}
    fallback() external payable {}
}