// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";

/// @title NexGen Staking Contract
/// @notice Production-ready staking with flexible rewards and multiple pools
/// @dev Perfect for DeFi projects, token incentives, and yield farming
contract NexGenStaking is Ownable, ReentrancyGuard, Pausable {
    using SafeERC20 for IERC20;

    // ============ TOKENS ============
    IERC20 public stakingToken;
    IERC20 public rewardToken;
    bool public sameToken; // If staking and reward token are the same

    // ============ POOL CONFIGURATION ============
    struct Pool {
        uint256 allocPoint;          // Allocation points
        uint256 lastRewardTime;      // Last reward distribution time
        uint256 accRewardPerShare;   // Accumulated rewards per share
        uint256 totalStaked;         // Total tokens staked in pool
        uint256 minStakeAmount;      // Minimum stake amount
        uint256 maxStakeAmount;      // Maximum stake amount (0 = unlimited)
        uint256 lockPeriod;          // Lock period in seconds (0 = no lock)
        bool isActive;               // Whether pool is active
    }

    Pool[] public pools;
    uint256 public totalAllocPoint;
    uint256 public rewardPerSecond;
    uint256 public startTime;
    uint256 public endTime;

    // ============ USER INFO ============
    struct UserInfo {
        uint256 amount;        // Amount staked
        uint256 rewardDebt;    // Reward debt
        uint256 lockEndTime;   // When lock ends
        uint256 lastStakeTime; // Last stake timestamp
    }

    mapping(uint256 => mapping(address => UserInfo)) public userInfo;

    // ============ BOOST ============
    mapping(address => uint256) public boostMultiplier; // 10000 = 1x
    uint256 public constant BOOST_PRECISION = 10000;
    uint256 public constant MAX_BOOST = 30000; // 3x max boost

    // ============ FEES ============
    uint256 public earlyUnstakeFee = 500; // 5% (basis points)
    uint256 public constant MAX_EARLY_UNSTAKE_FEE = 1000; // 10% max
    address public feeWallet;

    // ============ EVENTS ============
    event PoolCreated(uint256 indexed pid, uint256 allocPoint, uint256 minStake, uint256 lockPeriod);
    event Staked(address indexed user, uint256 indexed pid, uint256 amount);
    event Unstaked(address indexed user, uint256 indexed pid, uint256 amount);
    event RewardClaimed(address indexed user, uint256 indexed pid, uint256 amount);
    event EarlyUnstakeFee(address indexed user, uint256 fee);
    event RewardPerSecondUpdated(uint256 oldValue, uint256 newValue);
    event StartTimeUpdated(uint256 oldTime, uint256 newTime);
    event EndTimeUpdated(uint256 oldTime, uint256 newTime);
    event BoostUpdated(address indexed user, uint256 multiplier);
    event FeeWalletUpdated(address oldWallet, address newWallet);
    event EarlyUnstakeFeeUpdated(uint256 oldFee, uint256 newFee);

    constructor(
        address _stakingToken,
        address _rewardToken,
        uint256 _rewardPerSecond,
        uint256 _startTime,
        uint256 _endTime,
        address _feeWallet,
        address initialOwner
    ) Ownable(initialOwner) {
        require(_stakingToken != address(0), "Staking token cannot be zero");
        require(_rewardToken != address(0), "Reward token cannot be zero");
        require(_rewardPerSecond > 0, "Reward per second cannot be zero");
        require(_startTime >= block.timestamp, "Start time must be in future");
        require(_endTime > _startTime, "End time must be after start");
        require(_feeWallet != address(0), "Fee wallet cannot be zero");

        stakingToken = IERC20(_stakingToken);
        rewardToken = IERC20(_rewardToken);
        sameToken = _stakingToken == _rewardToken;
        rewardPerSecond = _rewardPerSecond;
        startTime = _startTime;
        endTime = _endTime;
        feeWallet = _feeWallet;
    }

    // ============ POOL MANAGEMENT ============

    /// @notice Create a new staking pool
    function createPool(
        uint256 _allocPoint,
        uint256 _minStakeAmount,
        uint256 _maxStakeAmount,
        uint256 _lockPeriod,
        bool _isActive
    ) external onlyOwner {
        uint256 lastRewardTime = block.timestamp > startTime ? block.timestamp : startTime;
        totalAllocPoint += _allocPoint;

        pools.push(Pool({
            allocPoint: _allocPoint,
            lastRewardTime: lastRewardTime,
            accRewardPerShare: 0,
            totalStaked: 0,
            minStakeAmount: _minStakeAmount,
            maxStakeAmount: _maxStakeAmount,
            lockPeriod: _lockPeriod,
            isActive: _isActive
        }));

        emit PoolCreated(pools.length - 1, _allocPoint, _minStakeAmount, _lockPeriod);
    }

    /// @notice Update pool allocation
    function setPoolAllocPoint(uint256 _pid, uint256 _allocPoint) external onlyOwner {
        require(_pid < pools.length, "Invalid pool");
        massUpdatePools();
        totalAllocPoint = totalAllocPoint - pools[_pid].allocPoint + _allocPoint;
        pools[_pid].allocPoint = _allocPoint;
    }

    /// @notice Toggle pool active status
    function setPoolActive(uint256 _pid, bool _isActive) external onlyOwner {
        require(_pid < pools.length, "Invalid pool");
        pools[_pid].isActive = _isActive;
    }

    /// @notice Update pool min stake amount
    function setPoolMinStake(uint256 _pid, uint256 _minStakeAmount) external onlyOwner {
        require(_pid < pools.length, "Invalid pool");
        pools[_pid].minStakeAmount = _minStakeAmount;
    }

    /// @notice Update pool max stake amount
    function setPoolMaxStake(uint256 _pid, uint256 _maxStakeAmount) external onlyOwner {
        require(_pid < pools.length, "Invalid pool");
        pools[_pid].maxStakeAmount = _maxStakeAmount;
    }

    /// @notice Update pool lock period
    function setPoolLockPeriod(uint256 _pid, uint256 _lockPeriod) external onlyOwner {
        require(_pid < pools.length, "Invalid pool");
        pools[_pid].lockPeriod = _lockPeriod;
    }

    // ============ STAKING ============

    /// @notice Stake tokens
    function stake(uint256 _pid, uint256 _amount) external nonReentrant whenNotPaused {
        require(_pid < pools.length, "Invalid pool");
        require(_amount > 0, "Amount must be greater than 0");
        require(block.timestamp >= startTime, "Staking not started");
        require(block.timestamp < endTime, "Staking ended");

        Pool storage pool = pools[_pid];
        require(pool.isActive, "Pool not active");
        require(_amount >= pool.minStakeAmount, "Below minimum stake");
        require(pool.maxStakeAmount == 0 || pool.totalStaked + _amount <= pool.maxStakeAmount, "Exceeds max stake");

        UserInfo storage user = userInfo[_pid][msg.sender];

        // Update pool rewards
        if (block.timestamp > pool.lastRewardTime) {
            uint256 reward = _calculatePoolReward(pool);
            pool.accRewardPerShare += (reward * 1e18) / pool.totalStaked;
            pool.lastRewardTime = block.timestamp;
        }

        // Calculate pending rewards
        if (user.amount > 0) {
            uint256 pending = (user.amount * pool.accRewardPerShare) / 1e18 - user.rewardDebt;
            if (pending > 0) {
                _safeRewardTransfer(msg.sender, pending);
            }
        }

        // Update user info
        user.amount += _amount;
        user.rewardDebt = (user.amount * pool.accRewardPerShare) / 1e18;
        user.lockEndTime = block.timestamp + pool.lockPeriod;
        user.lastStakeTime = block.timestamp;

        // Update pool
        pool.totalStaked += _amount;

        // Transfer tokens
        stakingToken.safeTransferFrom(msg.sender, address(this), _amount);

        emit Staked(msg.sender, _pid, _amount);
    }

    /// @notice Unstake tokens
    function unstake(uint256 _pid, uint256 _amount) external nonReentrant {
        require(_pid < pools.length, "Invalid pool");
        require(_amount > 0, "Amount must be greater than 0");

        Pool storage pool = pools[_pid];
        UserInfo storage user = userInfo[_pid][msg.sender];
        require(user.amount >= _amount, "Insufficient staked amount");

        // Check lock period
        if (pool.lockPeriod > 0) {
            require(block.timestamp >= user.lockEndTime, "Tokens still locked");
        }

        // Update pool rewards
        if (block.timestamp > pool.lastRewardTime) {
            uint256 reward = _calculatePoolReward(pool);
            pool.accRewardPerShare += (reward * 1e18) / pool.totalStaked;
            pool.lastRewardTime = block.timestamp;
        }

        // Calculate and claim pending rewards
        uint256 pending = (user.amount * pool.accRewardPerShare) / 1e18 - user.rewardDebt;
        if (pending > 0) {
            _safeRewardTransfer(msg.sender, pending);
        }

        // Check for early unstake fee
        uint256 fee = 0;
        if (user.lockEndTime > block.timestamp) {
            fee = (_amount * earlyUnstakeFee) / 10000;
            if (fee > 0) {
                stakingToken.safeTransfer(feeWallet, fee);
                emit EarlyUnstakeFee(msg.sender, fee);
            }
        }

        // Update user info
        user.amount -= _amount;
        user.rewardDebt = (user.amount * pool.accRewardPerShare) / 1e18;

        // Update pool
        pool.totalStaked -= _amount;

        // Transfer tokens (minus fee)
        stakingToken.safeTransfer(msg.sender, _amount - fee);

        emit Unstaked(msg.sender, _pid, _amount);
    }

    /// @notice Claim pending rewards
    function claimReward(uint256 _pid) external nonReentrant {
        require(_pid < pools.length, "Invalid pool");

        Pool storage pool = pools[_pid];
        UserInfo storage user = userInfo[_pid][msg.sender];
        require(user.amount > 0, "No staked amount");

        // Update pool rewards
        if (block.timestamp > pool.lastRewardTime) {
            uint256 reward = _calculatePoolReward(pool);
            pool.accRewardPerShare += (reward * 1e18) / pool.totalStaked;
            pool.lastRewardTime = block.timestamp;
        }

        // Calculate pending rewards
        uint256 pending = (user.amount * pool.accRewardPerShare) / 1e18 - user.rewardDebt;
        require(pending > 0, "No rewards to claim");

        // Update user debt
        user.rewardDebt = (user.amount * pool.accRewardPerShare) / 1e18;

        // Transfer rewards
        _safeRewardTransfer(msg.sender, pending);

        emit RewardClaimed(msg.sender, _pid, pending);
    }

    // ============ BOOST ============

    /// @notice Set boost multiplier for user (owner only)
    function setBoost(address _user, uint256 _multiplier) external onlyOwner {
        require(_user != address(0), "Cannot be zero address");
        require(_multiplier <= MAX_BOOST, "Exceeds max boost");
        boostMultiplier[_user] = _multiplier;
        emit BoostUpdated(_user, _multiplier);
    }

    /// @notice Set boost for multiple users
    function setBoostMultiple(address[] calldata _users, uint256[] calldata _multipliers) external onlyOwner {
        require(_users.length == _multipliers.length, "Length mismatch");
        for (uint256 i = 0; i < _users.length; i++) {
            require(_users[i] != address(0), "Cannot be zero address");
            require(_multipliers[i] <= MAX_BOOST, "Exceeds max boost");
            boostMultiplier[_users[i]] = _multipliers[i];
            emit BoostUpdated(_users[i], _multipliers[i]);
        }
    }

    /// @notice Get user boost multiplier
    function getUserBoost(address _user) public view returns (uint256) {
        uint256 boost = boostMultiplier[_user];
        return boost > 0 ? boost : BOOST_PRECISION; // Default 1x
    }

    // ============ CONFIGURATION ============

    /// @notice Update reward per second
    function setRewardPerSecond(uint256 _rewardPerSecond) external onlyOwner {
        massUpdatePools();
        uint256 oldValue = rewardPerSecond;
        rewardPerSecond = _rewardPerSecond;
        emit RewardPerSecondUpdated(oldValue, _rewardPerSecond);
    }

    /// @notice Update start time
    function setStartTime(uint256 _startTime) external onlyOwner {
        require(_startTime >= block.timestamp, "Start time must be in future");
        uint256 oldValue = startTime;
        startTime = _startTime;
        emit StartTimeUpdated(oldValue, _startTime);
    }

    /// @notice Update end time
    function setEndTime(uint256 _endTime) external onlyOwner {
        require(_endTime > startTime, "End time must be after start");
        uint256 oldValue = endTime;
        endTime = _endTime;
        emit EndTimeUpdated(oldValue, _endTime);
    }

    /// @notice Update early unstake fee
    function setEarlyUnstakeFee(uint256 _fee) external onlyOwner {
        require(_fee <= MAX_EARLY_UNSTAKE_FEE, "Fee too high");
        uint256 oldValue = earlyUnstakeFee;
        earlyUnstakeFee = _fee;
        emit EarlyUnstakeFeeUpdated(oldValue, _fee);
    }

    /// @notice Update fee wallet
    function setFeeWallet(address _feeWallet) external onlyOwner {
        require(_feeWallet != address(0), "Cannot be zero address");
        address oldWallet = feeWallet;
        feeWallet = _feeWallet;
        emit FeeWalletUpdated(oldWallet, _feeWallet);
    }

    // ============ ADMIN FUNCTIONS ============

    /// @notice Update all pools (call periodically)
    function massUpdatePools() public {
        uint256 length = pools.length;
        for (uint256 pid = 0; pid < length; pid++) {
            if (block.timestamp > pools[pid].lastRewardTime && pools[pid].totalStaked > 0) {
                uint256 reward = _calculatePoolReward(pools[pid]);
                pools[pid].accRewardPerShare += (reward * 1e18) / pools[pid].totalStaked;
                pools[pid].lastRewardTime = block.timestamp;
            } else {
                pools[pid].lastRewardTime = block.timestamp;
            }
        }
    }

    /// @notice Emergency withdraw (owner only)
    function emergencyWithdraw(uint256 _pid) external nonReentrant {
        require(_pid < pools.length, "Invalid pool");

        Pool storage pool = pools[_pid];
        UserInfo storage user = userInfo[_pid][msg.sender];
        require(user.amount > 0, "No staked amount");

        uint256 amount = user.amount;

        // Reset user info (no rewards)
        user.amount = 0;
        user.rewardDebt = 0;

        // Update pool
        pool.totalStaked -= amount;

        // Transfer tokens
        stakingToken.safeTransfer(msg.sender, amount);

        emit Unstaked(msg.sender, _pid, amount);
    }

    /// @notice Pause staking
    function pause() external onlyOwner {
        _pause();
    }

    /// @notice Unpause staking
    function unpause() external onlyOwner {
        _unpause();
    }

    // ============ VIEW FUNCTIONS ============

    /// @notice Get pool info
    function getPoolInfo(uint256 _pid) external view returns (
        uint256 allocPoint,
        uint256 lastRewardTime,
        uint256 accRewardPerShare,
        uint256 totalStaked,
        uint256 minStakeAmount,
        uint256 maxStakeAmount,
        uint256 lockPeriod,
        bool isActive
    ) {
        require(_pid < pools.length, "Invalid pool");
        Pool storage pool = pools[_pid];
        return (
            pool.allocPoint,
            pool.lastRewardTime,
            pool.accRewardPerShare,
            pool.totalStaked,
            pool.minStakeAmount,
            pool.maxStakeAmount,
            pool.lockPeriod,
            pool.isActive
        );
    }

    /// @notice Get user info
    function getUserInfo(uint256 _pid, address _user) external view returns (
        uint256 amount,
        uint256 rewardDebt,
        uint256 lockEndTime,
        uint256 lastStakeTime,
        uint256 pendingReward
    ) {
        require(_pid < pools.length, "Invalid pool");
        UserInfo storage user = userInfo[_pid][_user];
        Pool storage pool = pools[_pid];

        uint256 accRewardPerShare = pool.accRewardPerShare;
        if (block.timestamp > pool.lastRewardTime && pool.totalStaked > 0) {
            uint256 reward = _calculatePoolReward(pool);
            accRewardPerShare += (reward * 1e18) / pool.totalStaked;
        }

        uint256 pending = (user.amount * accRewardPerShare) / 1e18 - user.rewardDebt;

        return (
            user.amount,
            user.rewardDebt,
            user.lockEndTime,
            user.lastStakeTime,
            pending
        );
    }

    /// @notice Get total staked across all pools
    function getTotalStaked() external view returns (uint256) {
        uint256 total = 0;
        for (uint256 i = 0; i < pools.length; i++) {
            total += pools[i].totalStaked;
        }
        return total;
    }

    /// @notice Get APY for a pool
    function getPoolAPY(uint256 _pid) external view returns (uint256) {
        require(_pid < pools.length, "Invalid pool");
        Pool storage pool = pools[_pid];
        
        if (pool.totalStaked == 0 || totalAllocPoint == 0) {
            return 0;
        }

        uint256 poolRewardPerSecond = (rewardPerSecond * pool.allocPoint) / totalAllocPoint;
        uint256 yearlyReward = poolRewardPerSecond * 365 days;
        uint256 apy = (yearlyReward * 10000) / pool.totalStaked; // Basis points
        
        return apy;
    }

    /// @notice Get number of pools
    function getPoolCount() external view returns (uint256) {
        return pools.length;
    }

    // ============ INTERNAL FUNCTIONS ============

    function _calculatePoolReward(Pool storage pool) internal view returns (uint256) {
        uint256 endTime_ = block.timestamp > endTime ? endTime : block.timestamp;
        uint256 startTime_ = pool.lastRewardTime > startTime ? pool.lastRewardTime : startTime;
        
        if (endTime_ <= startTime_ || totalAllocPoint == 0) {
            return 0;
        }

        uint256 duration = endTime_ - startTime_;
        uint256 poolReward = (rewardPerSecond * duration * pool.allocPoint) / totalAllocPoint;
        
        return poolReward;
    }

    function _safeRewardTransfer(address _to, uint256 _amount) internal {
        uint256 rewardBal = rewardToken.balanceOf(address(this));
        if (_amount > rewardBal) {
            rewardToken.safeTransfer(_to, rewardBal);
        } else {
            rewardToken.safeTransfer(_to, _amount);
        }
    }

    // ============ RECEIVE ============

    receive() external payable {}
    fallback() external payable {}
}