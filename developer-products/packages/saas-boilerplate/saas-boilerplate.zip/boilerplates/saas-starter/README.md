# SaaS Boilerplate

> **Launch your SaaS in days, not months.**
> Auth, billing, dashboard, and deployment — all pre-built.

---

## 🚀 Features

- ✅ **Authentication** — Login, signup, forgot password, OAuth
- ✅ **Billing** — Stripe integration, subscriptions, invoices
- ✅ **Dashboard** — Charts, tables, real-time data
- ✅ **Email** — Transactional emails, templates
- ✅ **Database** — PostgreSQL with Prisma ORM
- ✅ **API** — RESTful API with validation
- ✅ **Deployment** — Vercel/Railway ready
- ✅ **Testing** — Unit and integration tests
- ✅ **Documentation** — Full API docs

---

## ⚡ Quick Start

### 1. Clone & Install

```bash
git clone https://github.com/nexgenai/saas-boilerplate.git
cd saas-boilerplate
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your keys
```

### 3. Setup Database

```bash
npx prisma migrate dev
npx prisma generate
```

### 4. Run Development Server

```bash
npm run dev
```

Visit `http://localhost:3000`

---

## 📁 Project Structure

```
saas-boilerplate/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── auth/
│   │   │   ├── billing/
│   │   │   └── users/
│   │   ├── dashboard/
│   │   ├── login/
│   │   └── signup/
│   ├── components/
│   │   ├── ui/
│   │   ├── forms/
│   │   └── charts/
│   ├── lib/
│   │   ├── auth.ts
│   │   ├── db.ts
│   │   ├── stripe.ts
│   │   └── email.ts
│   └── types/
├── prisma/
│   └── schema.prisma
├── public/
├── tests/
├── package.json
└── README.md
```

---

## 🔐 Authentication

### Features

- Email/password authentication
- OAuth (Google, GitHub)
- Magic link authentication
- Session management
- Role-based access control

### Usage

```typescript
import { auth } from '@/lib/auth';

// Protect API route
export async function GET(req: Request) {
    const session = await auth();
    if (!session) {
        return new Response('Unauthorized', { status: 401 });
    }
    return Response.json({ user: session.user });
}

// Protect page
export default function DashboardPage() {
    const { data: session } = useSession();
    if (!session) redirect('/login');
    return <Dashboard />;
}
```

---

## 💳 Billing (Stripe)

### Features

- Subscription management
- Usage-based billing
- Invoice generation
- Customer portal
- Webhook handling

### Setup

```typescript
import { stripe } from '@/lib/stripe';

// Create checkout session
const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    payment_method_types: ['card'],
    line_items: [{
        price: 'price_xxx',
        quantity: 1
    }],
    success_url: `${process.env.NEXT_PUBLIC_URL}/dashboard?success=true`,
    cancel_url: `${process.env.NEXT_PUBLIC_URL}/pricing?canceled=true`
});

// Customer portal
const portalSession = await stripe.billingPortal.sessions.create({
    customer: 'cus_xxx',
    return_url: `${process.env.NEXT_PUBLIC_URL}/dashboard`
});
```

### Webhook Handler

```typescript
// app/api/webhooks/stripe/route.ts
export async function POST(req: Request) {
    const body = await req.text();
    const sig = req.headers.get('stripe-signature')!;
    
    const event = stripe.webhooks.constructEvent(
        body,
        sig,
        process.env.STRIPE_WEBHOOK_SECRET!
    );

    switch (event.type) {
        case 'checkout.session.completed':
            // Handle successful checkout
            break;
        case 'invoice.paid':
            // Handle successful payment
            break;
        case 'customer.subscription.deleted':
            // Handle cancellation
            break;
    }

    return Response.json({ received: true });
}
```

---

## 📊 Dashboard

### Components

```tsx
import { 
    Card, 
    Chart, 
    Table, 
    Stats 
} from '@/components/ui';

export default function Dashboard() {
    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Stats 
                title="Revenue" 
                value="$12,345" 
                change="+12%" 
            />
            <Stats 
                title="Users" 
                value="1,234" 
                change="+5%" 
            />
            <Stats 
                title="Conversion" 
                value="3.2%" 
                change="+0.5%" 
            />
            <Stats 
                title="MRR" 
                value="$8,456" 
                change="+8%" 
            />
        </div>
    );
}
```

### Charts

```tsx
import { LineChart, BarChart, PieChart } from '@/components/charts';

<LineChart 
    data={revenueData}
    xKey="date"
    yKey="revenue"
    title="Revenue Over Time"
/>
```

---

## 📧 Email

### Templates

```typescript
import { sendEmail } from '@/lib/email';

// Welcome email
await sendEmail({
    to: user.email,
    subject: 'Welcome to NexGen!',
    template: 'welcome',
    data: { name: user.name }
});

// Invoice email
await sendEmail({
    to: user.email,
    subject: 'Your Invoice',
    template: 'invoice',
    data: { invoiceUrl: invoice.hosted_invoice_url }
});
```

### Custom Templates

```typescript
// lib/email/templates/welcome.tsx
export function WelcomeEmail({ name }: { name: string }) {
    return (
        <Html>
            <Head />
            <Body>
                <Container>
                    <Heading>Welcome, {name}!</Heading>
                    <Text>Thanks for signing up.</Text>
                </Container>
            </Body>
        </Html>
    );
}
```

---

## 🗄️ Database

### Schema

```prisma
// prisma/schema.prisma
model User {
    id            String    @id @default(cuid())
    email         String    @unique
    name          String?
    password      String
    role          Role      @default(USER)
    stripeCustomerId String?
    subscription  Subscription?
    createdAt     DateTime  @default(now())
    updatedAt     DateTime  @updatedAt
}

model Subscription {
    id                String   @id @default(cuid())
    userId            String   @unique
    user              User     @relation(fields: [userId], references: [id])
    stripeSubscriptionId String @unique
    status            Status
    plan              Plan
    currentPeriodEnd  DateTime
    createdAt         DateTime @default(now())
    updatedAt         DateTime @updatedAt
}

enum Role {
    USER
    ADMIN
}

enum Status {
    ACTIVE
    CANCELED
    PAST_DUE
}

enum Plan {
    FREE
    STARTER
    PRO
    ENTERPRISE
}
```

### Queries

```typescript
import { prisma } from '@/lib/db';

// Get user with subscription
const user = await prisma.user.findUnique({
    where: { email },
    include: { subscription: true }
});

// Create user
const user = await prisma.user.create({
    data: {
        email,
        name,
        password: hashedPassword
    }
});
```

---

## 🧪 Testing

### Unit Tests

```bash
npm run test
```

### Integration Tests

```bash
npm run test:integration
```

### E2E Tests

```bash
npm run test:e2e
```

### Example Test

```typescript
// tests/auth.test.ts
describe('Authentication', () => {
    it('should sign up a new user', async () => {
        const response = await request(app)
            .post('/api/auth/signup')
            .send({
                email: 'test@example.com',
                password: 'password123',
                name: 'Test User'
            });
        
        expect(response.status).toBe(201);
        expect(response.body.user).toBeDefined();
    });
});
```

---

## 🚀 Deployment

### Vercel

```bash
vercel deploy
```

### Railway

```bash
railway up
```

### Docker

```dockerfile
FROM node:18-alpine AS base
WORKDIR /app

FROM base AS deps
COPY package*.json ./
RUN npm ci

FROM base AS builder
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npx prisma generate
RUN npm run build

FROM base AS runner
COPY --from=builder /app/.next ./.next
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/package.json ./package.json
EXPOSE 3000
CMD ["npm", "start"]
```

---

## 📊 Pricing Tiers

### Starter ($149)
- Auth (email + OAuth)
- Stripe billing
- Basic dashboard
- Email templates
- 1 database

### Pro ($299)
- Everything in Starter
- Advanced dashboard
- Team management
- API documentation
- Analytics
- Priority support

### Enterprise ($499)
- Everything in Pro
- Custom integrations
- White-label
- Dedicated support
- SLA
- Training

---

## 📚 Resources

- [Next.js Docs](https://nextjs.org/docs)
- [Prisma Docs](https://www.prisma.io/docs)
- [Stripe Docs](https://stripe.com/docs)
- [Tailwind CSS Docs](https://tailwindcss.com/docs)

---

## 🆘 Support

- **Documentation:** [docs.nexgenai.dev](https://docs.nexgenai.dev)
- **Discord:** [discord.gg/nexgenai](https://discord.gg/nexgenai)
- **Email:** support@nexgenai.dev

---

## 📄 License

MIT License — See [LICENSE](LICENSE) for details.

---

**Built by NexGen AI — Launch your SaaS in days, not months.**